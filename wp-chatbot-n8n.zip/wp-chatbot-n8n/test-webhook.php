<?php
/**
 * Standalone webhook test script
 * Place this in your WordPress root directory and access via browser
 */

// Test webhook connection
function test_webhook_connection() {
    $webhook_url = 'https://agent47.site/webhook-test/wordpress';
    
    echo "<h2>Testing Webhook Connection</h2>";
    echo "<p><strong>URL:</strong> $webhook_url</p>";
    
    $test_payload = array(
        'test' => true,
        'message' => 'Test connection from WordPress',
        'timestamp' => date('Y-m-d H:i:s'),
        'session_id' => 'test_' . uniqid()
    );
    
    $args = array(
        'method' => 'POST',
        'timeout' => 45,
        'headers' => array(
            'Content-Type' => 'application/json'
        ),
        'sslverify' => false,
        'blocking' => true
    );
    
    echo "<p><strong>Payload:</strong> " . json_encode($test_payload) . "</p>";
    echo "<p><strong>Request Args:</strong> " . json_encode($args) . "</p>";
    
    // Test 1: HTTPS
    echo "<h3>Test 1: HTTPS Connection</h3>";
    $start_time = microtime(true);
    $response = wp_remote_request($webhook_url, $args);
    $end_time = microtime(true);
    $duration = round(($end_time - $start_time) * 1000, 2);
    
    echo "<p><strong>Duration:</strong> {$duration}ms</p>";
    
    if (is_wp_error($response)) {
        echo "<p style='color: red;'><strong>Error:</strong> " . $response->get_error_message() . "</p>";
        echo "<p><strong>Error Code:</strong> " . $response->get_error_code() . "</p>";
        
        // Test 2: HTTP fallback
        echo "<h3>Test 2: HTTP Fallback</h3>";
        $http_url = str_replace('https://', 'http://', $webhook_url);
        echo "<p><strong>HTTP URL:</strong> $http_url</p>";
        
        $start_time = microtime(true);
        $http_response = wp_remote_request($http_url, $args);
        $end_time = microtime(true);
        $duration = round(($end_time - $start_time) * 1000, 2);
        
        echo "<p><strong>Duration:</strong> {$duration}ms</p>";
        
        if (is_wp_error($http_response)) {
            echo "<p style='color: red;'><strong>HTTP Error:</strong> " . $http_response->get_error_message() . "</p>";
        } else {
            $http_response_code = wp_remote_retrieve_response_code($http_response);
            $http_response_body = wp_remote_retrieve_body($http_response);
            echo "<p style='color: green;'><strong>HTTP Success!</strong> Code: $http_response_code</p>";
            echo "<p><strong>Response:</strong> $http_response_body</p>";
        }
    } else {
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $response_headers = wp_remote_retrieve_headers($response);
        
        echo "<p style='color: green;'><strong>Success!</strong> Code: $response_code</p>";
        echo "<p><strong>Response:</strong> $response_body</p>";
        echo "<p><strong>Headers:</strong> " . json_encode($response_headers) . "</p>";
    }
}

// Check if WordPress is loaded
if (!function_exists('wp_remote_request')) {
    echo "<h1>WordPress Not Loaded</h1>";
    echo "<p>This script needs to be run from within WordPress. Please place it in your WordPress root directory.</p>";
    exit;
}

// Run the test
test_webhook_connection();

// Additional diagnostics
echo "<h2>System Information</h2>";
echo "<p><strong>PHP Version:</strong> " . phpversion() . "</p>";
echo "<p><strong>WordPress Version:</strong> " . get_bloginfo('version') . "</p>";
echo "<p><strong>Site URL:</strong> " . get_site_url() . "</p>";
echo "<p><strong>Home URL:</strong> " . get_home_url() . "</p>";

// Check if cURL is available
echo "<p><strong>cURL Available:</strong> " . (function_exists('curl_init') ? 'Yes' : 'No') . "</p>";

// Check SSL certificate info
if (function_exists('curl_init')) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://agent47.site');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $result = curl_exec($ch);
    $curl_error = curl_error($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "<p><strong>cURL Test to agent47.site:</strong> " . ($curl_error ? "Error: $curl_error" : "Success (HTTP $http_code)") . "</p>";
}
?> 