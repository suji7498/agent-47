<?php
/**
 * Plugin Name: WP Chatbot n8n
 * Plugin URI: https://yourwebsite.com/wp-chatbot-n8n
 * Description: A WordPress chatbot plugin that integrates with n8n workflows and AI agents via webhooks.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-chatbot-n8n
 * Domain Path: /languages
 * 
 * @package WP_Chatbot_N8N
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Plugin version
define('WP_CHATBOT_N8N_VERSION', '1.0.0');

// Plugin path
define('WP_CHATBOT_N8N_PATH', plugin_dir_path(__FILE__));

// Plugin URL
define('WP_CHATBOT_N8N_URL', plugin_dir_url(__FILE__));

/**
 * Main plugin class
 */
class WP_Chatbot_N8N {
    
    /**
     * Plugin instance
     * @var WP_Chatbot_N8N
     */
    private static $instance = null;
    
    /**
     * Get plugin instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init();
    }
    
    /**
     * Initialize plugin
     */
    private function init() {
        add_action('init', array($this, 'load_textdomain'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // Load classes
        $this->load_dependencies();
        
        // Initialize components
        if (is_admin()) {
            new WP_Chatbot_N8N_Admin();
        }
        
        new WP_Chatbot_N8N_Public();
        new WP_Chatbot_N8N_API();
        
        // Add HTTP filters for better localhost handling
        add_filter('http_request_args', array($this, 'modify_http_request_args'), 10, 2);
        
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Load plugin dependencies
     */
    private function load_dependencies() {
        require_once WP_CHATBOT_N8N_PATH . 'includes/class-chatbot-core.php';
        require_once WP_CHATBOT_N8N_PATH . 'includes/class-chatbot-api.php';
        require_once WP_CHATBOT_N8N_PATH . 'includes/class-chatbot-webhook.php';
        require_once WP_CHATBOT_N8N_PATH . 'includes/class-chatbot-database.php';
        require_once WP_CHATBOT_N8N_PATH . 'includes/class-chatbot-security.php';
        
        if (is_admin()) {
            require_once WP_CHATBOT_N8N_PATH . 'admin/class-chatbot-admin.php';
        }
        
        require_once WP_CHATBOT_N8N_PATH . 'public/class-chatbot-public.php';
    }
    
    /**
     * Load text domain for internationalization
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'wp-chatbot-n8n',
            false,
            dirname(plugin_basename(__FILE__)) . '/languages/'
        );
    }
    
    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_frontend_scripts() {
        wp_enqueue_script(
            'wp-chatbot-n8n-frontend',
            WP_CHATBOT_N8N_URL . 'public/js/chatbot-frontend.js',
            array('jquery'),
            WP_CHATBOT_N8N_VERSION,
            true
        );
        
        wp_enqueue_script(
            'wp-chatbot-n8n-ajax',
            WP_CHATBOT_N8N_URL . 'public/js/chatbot-ajax.js',
            array('jquery'),
            WP_CHATBOT_N8N_VERSION,
            true
        );
        
        wp_enqueue_style(
            'wp-chatbot-n8n-style',
            WP_CHATBOT_N8N_URL . 'public/css/chatbot-style.css',
            array(),
            WP_CHATBOT_N8N_VERSION
        );
        
        // Localize script for AJAX
        wp_localize_script('wp-chatbot-n8n-ajax', 'chatbot_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('chatbot_nonce'),
            'rest_url' => rest_url('wp-chatbot-n8n/v1/'),
            'rest_nonce' => wp_create_nonce('wp_rest')
        ));
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        if ('settings_page_wp-chatbot-n8n-settings' !== $hook) {
            return;
        }
        
        wp_enqueue_script(
            'wp-chatbot-n8n-admin',
            WP_CHATBOT_N8N_URL . 'admin/js/admin-script.js',
            array('jquery'),
            WP_CHATBOT_N8N_VERSION,
            true
        );
        
        wp_enqueue_style(
            'wp-chatbot-n8n-admin-style',
            WP_CHATBOT_N8N_URL . 'admin/css/admin-style.css',
            array(),
            WP_CHATBOT_N8N_VERSION
        );
        
        // Localize admin script for AJAX
        wp_localize_script('wp-chatbot-n8n-admin', 'chatbot_admin_nonce', wp_create_nonce('chatbot_admin_nonce'));
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create database tables
        $database = new WP_Chatbot_N8N_Database();
        $database->create_tables();
        
        // Set default options
        add_option('wp_chatbot_n8n_settings', array(
            'n8n_webhook_url' => '',
            'webhook_http_method' => 'POST',
            'chatbot_title' => __('Chat Assistant', 'wp-chatbot-n8n'),
            'chatbot_enabled' => true,
            'chat_position' => 'bottom-right'
        ));
        
        // Flush rewrite rules for REST API
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up temporary data if needed
        flush_rewrite_rules();
    }
    
    /**
     * Modify HTTP request args for better localhost handling
     */
    public function modify_http_request_args($args, $url) {
        // If the URL contains localhost, add some modifications for better compatibility
        if (strpos($url, 'localhost') !== false || strpos($url, '127.0.0.1') !== false) {
            $args['sslverify'] = false;
            $args['timeout'] = 30;
            $args['httpversion'] = '1.1';
        }
        return $args;
    }
}

// Initialize the plugin
WP_Chatbot_N8N::get_instance(); 