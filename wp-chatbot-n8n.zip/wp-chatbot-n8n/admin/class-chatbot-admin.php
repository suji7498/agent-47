<?php
/**
 * Admin dashboard functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Chatbot_N8N_Admin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_test_webhook', array($this, 'test_webhook_ajax'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_options_page(
            __('WP Chatbot n8n Settings', 'wp-chatbot-n8n'),
            __('Chatbot n8n', 'wp-chatbot-n8n'),
            'manage_options',
            'wp-chatbot-n8n-settings',
            array($this, 'settings_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting(
            'wp_chatbot_n8n_settings',
            'wp_chatbot_n8n_settings',
            array($this, 'sanitize_settings')
        );
        
        add_settings_section(
            'wp_chatbot_n8n_general',
            __('General Settings', 'wp-chatbot-n8n'),
            array($this, 'general_section_callback'),
            'wp-chatbot-n8n-settings'
        );
        
        add_settings_field(
            'n8n_webhook_url',
            __('n8n Webhook URL', 'wp-chatbot-n8n'),
            array($this, 'webhook_url_field'),
            'wp-chatbot-n8n-settings',
            'wp_chatbot_n8n_general'
        );
        
        add_settings_field(
            'webhook_http_method',
            __('HTTP Method', 'wp-chatbot-n8n'),
            array($this, 'http_method_field'),
            'wp-chatbot-n8n-settings',
            'wp_chatbot_n8n_general'
        );
        
        add_settings_field(
            'webhook_auth_token',
            __('Webhook Auth Token (Optional)', 'wp-chatbot-n8n'),
            array($this, 'auth_token_field'),
            'wp-chatbot-n8n-settings',
            'wp_chatbot_n8n_general'
        );
        
        add_settings_field(
            'chatbot_title',
            __('Chatbot Title', 'wp-chatbot-n8n'),
            array($this, 'chatbot_title_field'),
            'wp-chatbot-n8n-settings',
            'wp_chatbot_n8n_general'
        );
        
        add_settings_field(
            'chatbot_enabled',
            __('Enable Chatbot', 'wp-chatbot-n8n'),
            array($this, 'chatbot_enabled_field'),
            'wp-chatbot-n8n-settings',
            'wp_chatbot_n8n_general'
        );
        
        add_settings_field(
            'chat_position',
            __('Chat Position', 'wp-chatbot-n8n'),
            array($this, 'chat_position_field'),
            'wp-chatbot-n8n-settings',
            'wp_chatbot_n8n_general'
        );
        
        add_settings_field(
            'chatbot_theme',
            __('Chatbot Theme', 'wp-chatbot-n8n'),
            array($this, 'chatbot_theme_field'),
            'wp-chatbot-n8n-settings',
            'wp_chatbot_n8n_general'
        );
    }
    
    /**
     * Settings page
     */
    public function settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        if (isset($_GET['settings-updated'])) {
            add_settings_error(
                'wp_chatbot_n8n_messages',
                'wp_chatbot_n8n_message',
                __('Settings Saved', 'wp-chatbot-n8n'),
                'updated'
            );
        }
        
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <?php settings_errors('wp_chatbot_n8n_messages'); ?>
            
            <form action="options.php" method="post">
                <?php
                settings_fields('wp_chatbot_n8n_settings');
                do_settings_sections('wp-chatbot-n8n-settings');
                submit_button(__('Save Settings', 'wp-chatbot-n8n'));
                ?>
            </form>
            
            <div class="webhook-status-section">
                <h2><?php _e('Webhook Status', 'wp-chatbot-n8n'); ?></h2>
                <?php
                $settings = get_option('wp_chatbot_n8n_settings', array());
                $webhook_url = $settings['n8n_webhook_url'] ?? '';
                $http_method = $settings['webhook_http_method'] ?? 'POST';
                
                if (!empty($webhook_url)) {
                    echo '<div class="webhook-status connected">';
                    echo '<span class="status-indicator connected"></span>';
                    echo '<strong>' . __('Webhook Configured', 'wp-chatbot-n8n') . '</strong><br>';
                    echo '<small>' . __('URL:', 'wp-chatbot-n8n') . ' ' . esc_html($webhook_url) . '</small><br>';
                    echo '<small>' . __('Method:', 'wp-chatbot-n8n') . ' ' . esc_html($http_method) . '</small>';
                    echo '</div>';
                } else {
                    echo '<div class="webhook-status disconnected">';
                    echo '<span class="status-indicator disconnected"></span>';
                    echo '<strong>' . __('Webhook Not Configured', 'wp-chatbot-n8n') . '</strong><br>';
                    echo '<small>' . __('Please configure your n8n webhook URL above.', 'wp-chatbot-n8n') . '</small>';
                    echo '</div>';
                }
                ?>
            </div>
            
            <div class="webhook-test-section">
                <h2><?php _e('Test Webhook Connection', 'wp-chatbot-n8n'); ?></h2>
                <p><?php _e('Test your n8n webhook connection to ensure it\'s working properly.', 'wp-chatbot-n8n'); ?></p>
                <button type="button" id="test-webhook-btn" class="button button-secondary">
                    <?php _e('Test Connection', 'wp-chatbot-n8n'); ?>
                </button>
                <div id="test-result"></div>
            </div>
        </div>
        <?php
    }
    
    /**
     * General section callback
     */
    public function general_section_callback() {
        echo '<p>' . __('Configure your n8n webhook integration and chatbot settings.', 'wp-chatbot-n8n') . '</p>';
    }
    
    /**
     * Webhook URL field
     */
    public function webhook_url_field() {
        $settings = get_option('wp_chatbot_n8n_settings', array());
        $webhook_url = $settings['n8n_webhook_url'] ?? '';
        ?>
        <input type="url" 
               id="n8n_webhook_url" 
               name="wp_chatbot_n8n_settings[n8n_webhook_url]" 
               value="<?php echo esc_attr($webhook_url); ?>" 
               class="regular-text" />
        <p class="description">
            <?php _e('Enter the full URL of your n8n webhook endpoint. For local development, try using 127.0.0.1 instead of localhost if you experience connection issues.', 'wp-chatbot-n8n'); ?>
        </p>
        <?php
    }
    
    /**
     * HTTP Method field
     */
    public function http_method_field() {
        $settings = get_option('wp_chatbot_n8n_settings', array());
        $method = $settings['webhook_http_method'] ?? 'POST';
        ?>
        <select id="webhook_http_method" name="wp_chatbot_n8n_settings[webhook_http_method]">
            <option value="POST" <?php selected($method, 'POST'); ?>>
                <?php _e('POST', 'wp-chatbot-n8n'); ?>
            </option>
            <option value="GET" <?php selected($method, 'GET'); ?>>
                <?php _e('GET', 'wp-chatbot-n8n'); ?>
            </option>
            <option value="PUT" <?php selected($method, 'PUT'); ?>>
                <?php _e('PUT', 'wp-chatbot-n8n'); ?>
            </option>
            <option value="DELETE" <?php selected($method, 'DELETE'); ?>>
                <?php _e('DELETE', 'wp-chatbot-n8n'); ?>
            </option>
            <option value="PATCH" <?php selected($method, 'PATCH'); ?>>
                <?php _e('PATCH', 'wp-chatbot-n8n'); ?>
            </option>
        </select>
        <p class="description">
            <?php _e('Select the HTTP method for your webhook requests.', 'wp-chatbot-n8n'); ?>
        </p>
        <?php
    }
    
    /**
     * Auth token field
     */
    public function auth_token_field() {
        $settings = get_option('wp_chatbot_n8n_settings', array());
        $auth_token = $settings['webhook_auth_token'] ?? '';
        ?>
        <input type="password" 
               id="webhook_auth_token" 
               name="wp_chatbot_n8n_settings[webhook_auth_token]" 
               value="<?php echo esc_attr($auth_token); ?>" 
               class="regular-text" />
        <p class="description">
            <?php _e('Optional authentication token for your webhook.', 'wp-chatbot-n8n'); ?>
        </p>
        <?php
    }
    
    /**
     * Chatbot title field
     */
    public function chatbot_title_field() {
        $settings = get_option('wp_chatbot_n8n_settings', array());
        $title = $settings['chatbot_title'] ?? __('Chat Assistant', 'wp-chatbot-n8n');
        ?>
        <input type="text" 
               id="chatbot_title" 
               name="wp_chatbot_n8n_settings[chatbot_title]" 
               value="<?php echo esc_attr($title); ?>" 
               class="regular-text" />
        <?php
    }
    
    /**
     * Chatbot enabled field
     */
    public function chatbot_enabled_field() {
        $settings = get_option('wp_chatbot_n8n_settings', array());
        $enabled = $settings['chatbot_enabled'] ?? true;
        ?>
        <label>
            <input type="checkbox" 
                   id="chatbot_enabled" 
                   name="wp_chatbot_n8n_settings[chatbot_enabled]" 
                   value="1" 
                   <?php checked($enabled, true); ?> />
            <?php _e('Enable the chatbot on the frontend', 'wp-chatbot-n8n'); ?>
        </label>
        <?php
    }
    
    /**
     * Chat position field
     */
    public function chat_position_field() {
        $settings = get_option('wp_chatbot_n8n_settings', array());
        $position = $settings['chat_position'] ?? 'bottom-right';
        ?>
        <select id="chat_position" name="wp_chatbot_n8n_settings[chat_position]">
            <option value="bottom-right" <?php selected($position, 'bottom-right'); ?>>
                <?php _e('Bottom Right', 'wp-chatbot-n8n'); ?>
            </option>
            <option value="bottom-left" <?php selected($position, 'bottom-left'); ?>>
                <?php _e('Bottom Left', 'wp-chatbot-n8n'); ?>
            </option>
            <option value="top-right" <?php selected($position, 'top-right'); ?>>
                <?php _e('Top Right', 'wp-chatbot-n8n'); ?>
            </option>
            <option value="top-left" <?php selected($position, 'top-left'); ?>>
                <?php _e('Top Left', 'wp-chatbot-n8n'); ?>
            </option>
        </select>
        <?php
    }
    
    /**
     * Chatbot theme field
     */
    public function chatbot_theme_field() {
        $settings = get_option('wp_chatbot_n8n_settings', array());
        $theme = $settings['chatbot_theme'] ?? 'skyblue';
        ?>
        <div class="theme-selector">
            <select id="chatbot_theme" name="wp_chatbot_n8n_settings[chatbot_theme]">
                <option value="skyblue" <?php selected($theme, 'skyblue'); ?>>
                    <?php _e('Sky Blue (Popular for IT/Tech)', 'wp-chatbot-n8n'); ?>
                </option>
                <option value="black" <?php selected($theme, 'black'); ?>>
                    <?php _e('Black (Professional/Elegant)', 'wp-chatbot-n8n'); ?>
                </option>
                <option value="pinkish" <?php selected($theme, 'pinkish'); ?>>
                    <?php _e('Pinkish (Fashion/Beauty)', 'wp-chatbot-n8n'); ?>
                </option>
                <option value="green" <?php selected($theme, 'green'); ?>>
                    <?php _e('Green (Eco-friendly/Health)', 'wp-chatbot-n8n'); ?>
                </option>
                <option value="purple" <?php selected($theme, 'purple'); ?>>
                    <?php _e('Purple (Creative/Arts)', 'wp-chatbot-n8n'); ?>
                </option>
            </select>
            <div class="theme-preview">
                <div class="theme-preview-box skyblue-theme" data-theme="skyblue"></div>
                <div class="theme-preview-box black-theme" data-theme="black"></div>
                <div class="theme-preview-box pinkish-theme" data-theme="pinkish"></div>
                <div class="theme-preview-box green-theme" data-theme="green"></div>
                <div class="theme-preview-box purple-theme" data-theme="purple"></div>
            </div>
        </div>
        <p class="description">
            <?php _e('Choose a color theme for your chatbot. Each theme is optimized for different industries and user preferences.', 'wp-chatbot-n8n'); ?>
        </p>
        <?php
    }
    
    /**
     * Sanitize settings
     */
    public function sanitize_settings($input) {
        $sanitized = array();
        
        if (isset($input['n8n_webhook_url'])) {
            $sanitized['n8n_webhook_url'] = WP_Chatbot_N8N_Security::sanitize_webhook_url($input['n8n_webhook_url']);
        }
        
        if (isset($input['webhook_http_method'])) {
            $allowed_methods = array('POST', 'GET', 'PUT', 'DELETE', 'PATCH');
            $sanitized['webhook_http_method'] = in_array($input['webhook_http_method'], $allowed_methods) 
                ? $input['webhook_http_method'] 
                : 'POST';
        }
        
        if (isset($input['webhook_auth_token'])) {
            $sanitized['webhook_auth_token'] = sanitize_text_field($input['webhook_auth_token']);
        }
        
        if (isset($input['chatbot_title'])) {
            $sanitized['chatbot_title'] = sanitize_text_field($input['chatbot_title']);
        }
        
        $sanitized['chatbot_enabled'] = isset($input['chatbot_enabled']) ? true : false;
        
        if (isset($input['chat_position'])) {
            $allowed_positions = array('bottom-right', 'bottom-left', 'top-right', 'top-left');
            $sanitized['chat_position'] = in_array($input['chat_position'], $allowed_positions) 
                ? $input['chat_position'] 
                : 'bottom-right';
        }
        
        if (isset($input['chatbot_theme'])) {
            $allowed_themes = array('skyblue', 'black', 'pinkish', 'green', 'purple');
            $sanitized['chatbot_theme'] = in_array($input['chatbot_theme'], $allowed_themes) 
                ? $input['chatbot_theme'] 
                : 'skyblue';
        }
        
        return $sanitized;
    }
    
    /**
     * Test webhook AJAX handler
     */
    public function test_webhook_ajax() {
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'wp-chatbot-n8n'));
        }
        
        check_ajax_referer('chatbot_admin_nonce', 'nonce');
        
        $settings = get_option('wp_chatbot_n8n_settings', array());
        $webhook_url = $settings['n8n_webhook_url'] ?? '';
        
        // Allow testing with a different URL if provided
        if (!empty($_POST['webhook_url'])) {
            $webhook_url = sanitize_url($_POST['webhook_url']);
        }
        
        if (empty($webhook_url)) {
            wp_send_json_error(__('Webhook URL not configured', 'wp-chatbot-n8n'));
        }
        
        // Allow testing with a different HTTP method if provided
        if (!empty($_POST['http_method'])) {
            $settings['webhook_http_method'] = sanitize_text_field($_POST['http_method']);
        }
        
        $webhook = new WP_Chatbot_N8N_Webhook();
        $result = $webhook->test_webhook($webhook_url);
        
        if ($result['success']) {
            wp_send_json_success($result['message']);
        } else {
            wp_send_json_error($result['message']);
        }
    }
} 