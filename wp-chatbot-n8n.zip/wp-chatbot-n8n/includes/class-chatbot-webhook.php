<?php
/**
 * n8n webhook integration
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Chatbot_N8N_Webhook {
    
    /**
     * Send message to n8n webhook
     * 
     * @param string $message User message
     * @param string $session_id Session ID
     * @return array|false Response from n8n or false on failure
     */
    public function send_message($message, $session_id) {
        
        $settings = get_option('wp_chatbot_n8n_settings', array());
        $webhook_url = $settings['n8n_webhook_url'] ?? '';
        $http_method = $settings['webhook_http_method'] ?? 'POST';
        
        if (empty($webhook_url)) {
            error_log('WP Chatbot n8n: Webhook URL not configured');
            return false;
        }
        
        // Prepare payload
        $payload = array(
            'message' => $message,
            'session_id' => $session_id,
            'timestamp' => current_time('mysql'),
            'user_id' => get_current_user_id(),
            'site_url' => home_url()
        );
        
        // Prepare request args
        $args = array(
            'method' => $http_method,
            'timeout' => 45, // Increased timeout
            'headers' => array(
                'Content-Type' => 'application/json',
                'User-Agent' => 'WP-Chatbot-n8n/' . WP_CHATBOT_N8N_VERSION
            ),
            'sslverify' => false, // Disable SSL verification for troubleshooting
            'httpversion' => '1.1',
            'blocking' => true,
            'cookies' => array()
        );
        
        // Handle different HTTP methods
        if ($http_method === 'GET') {
            // For GET requests, add payload as query parameters
            $webhook_url = add_query_arg($payload, $webhook_url);
        } else {
            // For other methods, add payload as body
            $args['body'] = wp_json_encode($payload);
        }
        
        // Add authentication if configured
        if (!empty($settings['webhook_auth_token'])) {
            $args['headers']['Authorization'] = 'Bearer ' . $settings['webhook_auth_token'];
        }
        
        // Log the request details for debugging
        error_log('WP Chatbot n8n: Sending webhook request to: ' . $webhook_url);
        error_log('WP Chatbot n8n: Request method: ' . $http_method);
        error_log('WP Chatbot n8n: Request payload: ' . wp_json_encode($payload));
        
        // Send request
        $response = wp_remote_request($webhook_url, $args);
        
        // Handle errors
        if (is_wp_error($response)) {
            $error_message = 'Webhook request failed - ' . $response->get_error_message();
            error_log('WP Chatbot n8n: ' . $error_message);
            error_log('WP Chatbot n8n: Error code: ' . $response->get_error_code());
            return false;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200) {
            error_log('WP Chatbot n8n: Webhook returned error code ' . $response_code . ' - ' . $response_body);
            return false;
        }
        
        // Parse JSON response
        $data = json_decode($response_body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('WP Chatbot n8n: Invalid JSON response from webhook - ' . $response_body);
            return false;
        }
        
        // Log the parsed response for debugging
        error_log('WP Chatbot n8n: Parsed response data: ' . wp_json_encode($data));
        
        // Ensure we have the expected response format
        if (!isset($data['message']) && !isset($data['output']) && !isset($data['response'])) {
            error_log('WP Chatbot n8n: Response missing message field - ' . $response_body);
            return false;
        }
        
        // Normalize the response format - handle multiple possible field names
        $message = '';
        if (isset($data['message'])) {
            $message = $data['message'];
        } elseif (isset($data['output'])) {
            $message = $data['output'];
        } elseif (isset($data['response'])) {
            $message = $data['response'];
        } elseif (is_string($data)) {
            // Handle case where response is just a string
            $message = $data;
        }
        
        $normalized_response = array(
            'message' => $message,
            'success' => $data['success'] ?? true,
            'timestamp' => $data['timestamp'] ?? current_time('mysql'),
            'session_id' => $data['session_id'] ?? $session_id
        );
        
        return $normalized_response;
    }
    
    /**
     * Test webhook connection
     * 
     * @param string $webhook_url Webhook URL to test
     * @return array Test result
     */
    public function test_webhook($webhook_url) {
        
        $settings = get_option('wp_chatbot_n8n_settings', array());
        $http_method = $settings['webhook_http_method'] ?? 'POST';
        
        $test_payload = array(
            'test' => true,
            'message' => 'Test connection from WordPress',
            'timestamp' => current_time('mysql'),
            'session_id' => 'test_' . uniqid()
        );
        
        $args = array(
            'method' => $http_method,
            'timeout' => 45, // Increased timeout for testing
            'headers' => array(
                'Content-Type' => 'application/json'
            ),
            'sslverify' => false,
            'blocking' => true
        );
        
        // Handle different HTTP methods for test
        if ($http_method === 'GET') {
            $webhook_url = add_query_arg($test_payload, $webhook_url);
        } else {
            $args['body'] = wp_json_encode($test_payload);
        }
        
        // Add authentication if configured
        if (!empty($settings['webhook_auth_token'])) {
            $args['headers']['Authorization'] = 'Bearer ' . $settings['webhook_auth_token'];
        }
        
        // Log the request details for debugging
        error_log('WP Chatbot n8n: Testing webhook - URL: ' . $webhook_url . ', Method: ' . $http_method);
        error_log('WP Chatbot n8n: Test payload: ' . wp_json_encode($test_payload));
        error_log('WP Chatbot n8n: Request args: ' . wp_json_encode($args));
        
        $response = wp_remote_request($webhook_url, $args);
        
        if (is_wp_error($response)) {
            $error_message = 'Connection failed: ' . $response->get_error_message();
            error_log('WP Chatbot n8n: ' . $error_message);
            
            // Try HTTP fallback if HTTPS failed
            if (strpos($webhook_url, 'https://') === 0) {
                $http_url = str_replace('https://', 'http://', $webhook_url);
                error_log('WP Chatbot n8n: Trying HTTP fallback: ' . $http_url);
                
                $http_response = wp_remote_request($http_url, $args);
                if (!is_wp_error($http_response)) {
                    $http_response_code = wp_remote_retrieve_response_code($http_response);
                    if ($http_response_code === 200) {
                        return array(
                            'success' => true,
                            'message' => __('Webhook connection successful via HTTP! Consider using HTTPS for production.', 'wp-chatbot-n8n')
                        );
                    }
                }
            }
            
            return array(
                'success' => false,
                'message' => $error_message
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $response_headers = wp_remote_retrieve_headers($response);
        
        error_log('WP Chatbot n8n: Test response code: ' . $response_code);
        error_log('WP Chatbot n8n: Test response body: ' . $response_body);
        
        if ($response_code === 200) {
            return array(
                'success' => true,
                'message' => __('Webhook connection successful! Response received.', 'wp-chatbot-n8n')
            );
        }
        
        $error_message = sprintf(__('Webhook returned error code: %d. Response: %s', 'wp-chatbot-n8n'), $response_code, $response_body);
        error_log('WP Chatbot n8n: ' . $error_message);
        
        return array(
            'success' => false,
            'message' => $error_message
        );
    }
} 