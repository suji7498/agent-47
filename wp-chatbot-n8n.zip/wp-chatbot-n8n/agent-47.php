<?php
/**
 * Plugin Name: Agent-47
 * Plugin URI: https://wordpress.org/plugins/agent-47/
 * Description: A flexible WordPress plugin that integrates with n8n workflows to create intelligent chatbots for your website. Features customizable UI, multiple themes, and seamless n8n integration.
 * Version: 1.0.0
 * Author: Suraj Jadhao
 * Author URI: https://www.linkedin.com/in/suraj-jd/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: agent-47
 * Domain Path: /languages
 * Requires at least: 5.8
 * Tested up to: 6.5
 * Requires PHP: 7.4
 * Network: false
 * 
 * @package Agent_47
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Plugin version
define('AGENT_47_VERSION', '1.0.0');

// Plugin path
define('AGENT_47_PATH', plugin_dir_path(__FILE__));

// Plugin URL
define('AGENT_47_URL', plugin_dir_url(__FILE__));

/**
 * Main plugin class
 */
class Agent_47 {
    
    /**
     * Plugin instance
     * @var Agent_47
     */
    private static $instance = null;
    
    /**
     * Get plugin instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init();
    }
    
    /**
     * Initialize plugin
     */
    private function init() {
        add_action('init', array($this, 'load_textdomain'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // Load classes
        $this->load_dependencies();
        
        // Initialize components
        if (is_admin()) {
            new Agent_47_Admin();
        }
        
        new Agent_47_Public();
        new Agent_47_API();
        
        // Add HTTP filters for better localhost handling
        add_filter('http_request_args', array($this, 'modify_http_request_args'), 10, 2);
        
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Load plugin dependencies
     */
    private function load_dependencies() {
        require_once AGENT_47_PATH . 'includes/class-chatbot-core.php';
        require_once AGENT_47_PATH . 'includes/class-chatbot-api.php';
        require_once AGENT_47_PATH . 'includes/class-chatbot-webhook.php';
        require_once AGENT_47_PATH . 'includes/class-chatbot-database.php';
        require_once AGENT_47_PATH . 'includes/class-chatbot-security.php';
        
        if (is_admin()) {
            require_once AGENT_47_PATH . 'admin/class-chatbot-admin.php';
        }
        
        require_once AGENT_47_PATH . 'public/class-chatbot-public.php';
    }
    
    /**
     * Load text domain for internationalization
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'agent-47',
            false,
            dirname(plugin_basename(__FILE__)) . '/languages/'
        );
    }
    
    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_frontend_scripts() {
        wp_enqueue_script(
            'agent-47-frontend',
            AGENT_47_URL . 'public/js/chatbot-frontend.js',
            array('jquery'),
            AGENT_47_VERSION,
            true
        );
        
        wp_enqueue_script(
            'agent-47-ajax',
            AGENT_47_URL . 'public/js/chatbot-ajax.js',
            array('jquery'),
            AGENT_47_VERSION,
            true
        );
        
        wp_enqueue_style(
            'agent-47-style',
            AGENT_47_URL . 'public/css/chatbot-style.css',
            array(),
            AGENT_47_VERSION
        );
        
        // Localize script for AJAX
        wp_localize_script('agent-47-ajax', 'chatbot_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('chatbot_nonce'),
            'rest_url' => rest_url('agent-47/v1/'),
            'rest_nonce' => wp_create_nonce('wp_rest')
        ));
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        if ('settings_page_agent-47-settings' !== $hook) {
            return;
        }
        
        wp_enqueue_script(
            'agent-47-admin',
            AGENT_47_URL . 'admin/js/admin-script.js',
            array('jquery'),
            AGENT_47_VERSION,
            true
        );
        
        wp_enqueue_style(
            'agent-47-admin-style',
            AGENT_47_URL . 'admin/css/admin-style.css',
            array(),
            AGENT_47_VERSION
        );
        
        // Localize admin script for AJAX
        wp_localize_script('agent-47-admin', 'chatbot_admin_nonce', wp_create_nonce('chatbot_admin_nonce'));
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create database tables
        $database = new Agent_47_Database();
        $database->create_tables();
        
        // Set default options
        add_option('agent_47_settings', array(
            'n8n_webhook_url' => '',
            'webhook_http_method' => 'POST',
            'chatbot_title' => __('Chat Assistant', 'agent-47'),
            'chatbot_enabled' => true,
            'chat_position' => 'bottom-right'
        ));
        
        // Flush rewrite rules for REST API
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up temporary data if needed
        flush_rewrite_rules();
    }
    
    /**
     * Modify HTTP request args for better localhost handling
     */
    public function modify_http_request_args($args, $url) {
        // If the URL contains localhost, add some modifications for better compatibility
        if (strpos($url, 'localhost') !== false || strpos($url, '127.0.0.1') !== false) {
            $args['sslverify'] = false;
            $args['timeout'] = 30;
            $args['httpversion'] = '1.1';
        }
        return $args;
    }
}

// Initialize the plugin
Agent_47::get_instance(); 