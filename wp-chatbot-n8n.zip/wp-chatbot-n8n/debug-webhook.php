<?php
/**
 * Debug webhook response script
 * Place this in your WordPress root directory and access via browser
 */

// Test webhook with detailed response analysis
function debug_webhook_response() {
    $webhook_url = 'https://agent47.site/webhook-test/wordpress';
    
    echo "<h2>Debug Webhook Response</h2>";
    echo "<p><strong>URL:</strong> $webhook_url</p>";
    
    $test_payload = array(
        'test' => true,
        'message' => 'Debug test message',
        'timestamp' => date('Y-m-d H:i:s'),
        'session_id' => 'debug_' . uniqid()
    );
    
    $args = array(
        'method' => 'POST',
        'timeout' => 60,
        'headers' => array(
            'Content-Type' => 'application/json'
        ),
        'sslverify' => false,
        'blocking' => true
    );
    
    $args['body'] = wp_json_encode($test_payload);
    
    echo "<p><strong>Request Payload:</strong></p>";
    echo "<pre>" . json_encode($test_payload, JSON_PRETTY_PRINT) . "</pre>";
    
    echo "<h3>Sending Request...</h3>";
    $start_time = microtime(true);
    $response = wp_remote_request($webhook_url, $args);
    $end_time = microtime(true);
    $duration = round(($end_time - $start_time) * 1000, 2);
    
    echo "<p><strong>Request Duration:</strong> {$duration}ms</p>";
    
    if (is_wp_error($response)) {
        echo "<p style='color: red;'><strong>Error:</strong> " . $response->get_error_message() . "</p>";
        echo "<p><strong>Error Code:</strong> " . $response->get_error_code() . "</p>";
        return;
    }
    
    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = wp_remote_retrieve_body($response);
    $response_headers = wp_remote_retrieve_headers($response);
    
    echo "<h3>Response Analysis</h3>";
    echo "<p><strong>Response Code:</strong> $response_code</p>";
    echo "<p><strong>Response Headers:</strong></p>";
    echo "<pre>" . json_encode($response_headers, JSON_PRETTY_PRINT) . "</pre>";
    
    echo "<p><strong>Raw Response Body:</strong></p>";
    echo "<pre>" . htmlspecialchars($response_body) . "</pre>";
    
    // Try to parse JSON
    $parsed_data = json_decode($response_body, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        echo "<p style='color: green;'><strong>JSON Parsing:</strong> Success</p>";
        echo "<p><strong>Parsed Data:</strong></p>";
        echo "<pre>" . json_encode($parsed_data, JSON_PRETTY_PRINT) . "</pre>";
        
        // Check for expected fields
        echo "<h3>Field Analysis</h3>";
        $expected_fields = ['message', 'output', 'success', 'timestamp'];
        foreach ($expected_fields as $field) {
            if (isset($parsed_data[$field])) {
                echo "<p style='color: green;'>✓ <strong>$field:</strong> " . htmlspecialchars($parsed_data[$field]) . "</p>";
            } else {
                echo "<p style='color: orange;'>✗ <strong>$field:</strong> Not found</p>";
            }
        }
        
        // Check if response is usable by the chatbot
        if (isset($parsed_data['message']) || isset($parsed_data['output'])) {
            $message = $parsed_data['message'] ?? $parsed_data['output'] ?? '';
            echo "<p style='color: green;'><strong>Chatbot Message:</strong> " . htmlspecialchars($message) . "</p>";
        } else {
            echo "<p style='color: red;'><strong>Error:</strong> No message field found for chatbot</p>";
        }
    } else {
        echo "<p style='color: red;'><strong>JSON Parsing Error:</strong> " . json_last_error_msg() . "</p>";
        echo "<p><strong>Response is not valid JSON</strong></p>";
    }
}

// Check if WordPress is loaded
if (!function_exists('wp_remote_request')) {
    echo "<h1>WordPress Not Loaded</h1>";
    echo "<p>This script needs to be run from within WordPress. Please place it in your WordPress root directory.</p>";
    exit;
}

// Run the debug
debug_webhook_response();
?> 