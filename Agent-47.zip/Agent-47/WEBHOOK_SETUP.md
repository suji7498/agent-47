# n8n Webhook Setup Guide

## Overview
This guide will help you set up the n8n webhook integration with your WordPress chatbot plugin.

## Prerequisites
- n8n instance running (local or cloud)
- WordPress site with the Agent-47 plugin installed
- Basic understanding of n8n workflows

## Step 1: Create n8n Webhook Node

1. **Open your n8n instance** and create a new workflow
2. **Add a Webhook node** to your workflow
3. **Configure the Webhook node:**
   - **HTTP Method**: Set to `POST` (recommended) or your preferred method
   - **Path**: Set to `wordpress` (or your preferred path)
   - **Authentication**: Set to `None` (or configure if needed)
   - **Respond**: Set to `Using 'Respond to Webhook' Node`

## Step 2: Configure Webhook URL

Your webhook URL will look like:
- **Local n8n**: `http://localhost:5678/webhook-test/wordpress`
- **Alternative local URLs** (if localhost doesn't work):
  - `http://127.0.0.1:5678/webhook-test/wordpress`
  - `http://[::1]:5678/webhook-test/wordpress`
- **Cloud n8n**: `https://your-instance.n8n.cloud/webhook-test/wordpress`

**Note**: If you experience connection issues with `localhost`, try using `127.0.0.1` instead.

## Step 3: Add Response Node

1. **Add a "Respond to Webhook" node** after your webhook processing
2. **Configure the response:**
   ```json
   {
     "message": "Your response message here",
     "success": true
   }
   ```

## Step 4: Configure WordPress Plugin

1. **Go to WordPress Admin** → Settings → Chatbot n8n
2. **Enter your webhook URL** in the "n8n Webhook URL" field
3. **Select HTTP Method** (should match your n8n webhook configuration)
4. **Test the connection** using the "Test Connection" button

## Step 5: Test the Integration

1. **Click "Test Connection"** in the WordPress admin
2. **Check the response** - you should see a success message
3. **If it fails**, check the error message and troubleshoot

## Troubleshooting

### Common Issues

1. **Connection Failed**
   - Verify your n8n instance is running
   - Check the webhook URL is correct
   - Ensure the HTTP method matches

2. **Error Code 404**
   - Verify the webhook path is correct
   - Check if the webhook node is active in n8n

3. **Error Code 500**
   - Check your n8n workflow for errors
   - Verify the "Respond to Webhook" node is configured

4. **CORS Issues**
   - Ensure your n8n instance allows requests from your WordPress domain
   - Check if you need to configure CORS headers

### Debug Information

The plugin logs detailed information to help troubleshoot:
- Check your WordPress error logs for entries starting with "Agent-47:"
- The test connection will show detailed error messages
- Verify the request payload and response in the logs

## Advanced Configuration

### Authentication
If your n8n webhook requires authentication:
1. Configure authentication in your n8n webhook node
2. Add the authentication token in the WordPress plugin settings

### Custom Payload
The plugin sends this payload to your webhook:
```json
{
  "message": "User message",
  "session_id": "unique_session_id",
  "timestamp": "2024-01-01 12:00:00",
  "user_id": 1,
  "site_url": "https://your-site.com"
}
```

### Custom Response
Your n8n workflow should respond with:
```json
{
  "message": "Bot response message",
  "success": true
}
```

## Security Considerations

1. **Use HTTPS** for production webhooks
2. **Implement authentication** if needed
3. **Validate input** in your n8n workflow
4. **Rate limiting** to prevent abuse

## Support

If you continue to have issues:
1. Check the WordPress error logs
2. Verify your n8n workflow is working
3. Test the webhook URL directly (using tools like Postman)
4. Ensure all settings match between WordPress and n8n 