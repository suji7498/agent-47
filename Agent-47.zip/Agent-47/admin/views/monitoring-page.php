<?php
/**
 * Monitoring Dashboard View
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1><?php esc_html_e('Agent-47 Monitoring Dashboard', 'agent-47'); ?></h1>
    
    <div class="agent-47-monitoring-grid">
        <!-- System Status -->
        <div class="agent-47-card">
            <h2><?php esc_html_e('System Status', 'agent-47'); ?></h2>
            <div class="status-grid">
                <div class="status-item">
                    <span class="status-label"><?php esc_html_e('Active Sessions:', 'agent-47'); ?></span>
                    <span class="status-value <?php echo $core_status['active_sessions'] > 150 ? 'warning' : 'normal'; ?>">
                        <?php echo esc_html($core_status['active_sessions']); ?> / <?php echo esc_html($core_status['max_concurrent_sessions']); ?>
                    </span>
                </div>
                <div class="status-item">
                    <span class="status-label"><?php esc_html_e('Memory Usage:', 'agent-47'); ?></span>
                    <span class="status-value">
                        <?php echo esc_html(size_format($core_status['memory_usage'])); ?> / <?php echo esc_html($core_status['memory_limit']); ?>
                    </span>
                </div>
                <div class="status-item">
                    <span class="status-label"><?php esc_html_e('Session Timeout:', 'agent-47'); ?></span>
                    <span class="status-value">
                        <?php echo esc_html($core_status['session_timeout'] / 60); ?> <?php esc_html_e('minutes', 'agent-47'); ?>
                    </span>
                </div>
                <div class="status-item">
                    <span class="status-label"><?php esc_html_e('Rate Limit:', 'agent-47'); ?></span>
                    <span class="status-value">
                        <?php echo esc_html($core_status['rate_limit_per_minute']); ?> <?php esc_html_e('per minute', 'agent-47'); ?>
                    </span>
                </div>
            </div>
        </div>
        
        <!-- Today's Statistics -->
        <div class="agent-47-card">
            <h2><?php esc_html_e("Today's Statistics", 'agent-47'); ?></h2>
            <div class="stats-grid">
                <div class="stat-item">
                    <div class="stat-number"><?php echo esc_html($system_stats['sessions_today']); ?></div>
                    <div class="stat-label"><?php esc_html_e('New Sessions', 'agent-47'); ?></div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo esc_html($system_stats['messages_today']); ?></div>
                    <div class="stat-label"><?php esc_html_e('Messages', 'agent-47'); ?></div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo esc_html(round($system_stats['avg_messages_per_session'], 1)); ?></div>
                    <div class="stat-label"><?php esc_html_e('Avg Messages/Session', 'agent-47'); ?></div>
                </div>
            </div>
        </div>
        
        <!-- Performance Metrics -->
        <div class="agent-47-card">
            <h2><?php esc_html_e('Performance Metrics', 'agent-47'); ?></h2>
            <div class="metrics-grid">
                <div class="metric-item">
                    <span class="metric-label"><?php esc_html_e('Peak Concurrent (24h):', 'agent-47'); ?></span>
                    <span class="metric-value"><?php echo esc_html($performance_metrics['peak_concurrent_24h']); ?></span>
                </div>
                <div class="metric-item">
                    <span class="metric-label"><?php esc_html_e('Active Sessions:', 'agent-47'); ?></span>
                    <span class="metric-value"><?php echo esc_html($system_stats['active_sessions']); ?></span>
                </div>
            </div>
        </div>
        
        <!-- System Health -->
        <div class="agent-47-card">
            <h2><?php esc_html_e('System Health', 'agent-47'); ?></h2>
            <div class="health-grid">
                <?php
                $health_status = 'good';
                $health_message = __('System is running optimally', 'agent-47');
                
                if ($core_status['active_sessions'] > 150) {
                    $health_status = 'warning';
                    $health_message = __('High concurrent sessions detected', 'agent-47');
                }
                
                if ($core_status['active_sessions'] > 180) {
                    $health_status = 'critical';
                    $health_message = __('System under heavy load', 'agent-47');
                }
                ?>
                <div class="health-indicator <?php echo esc_attr($health_status); ?>">
                    <span class="health-dot"></span>
                    <span class="health-text"><?php echo esc_html($health_message); ?></span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Real-time Updates -->
    <div class="agent-47-card full-width">
        <h2><?php esc_html_e('Real-time Updates', 'agent-47'); ?></h2>
        <div id="real-time-stats">
            <p><?php esc_html_e('Loading real-time data...', 'agent-47'); ?></p>
        </div>
    </div>
</div>

<style>
.agent-47-monitoring-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.agent-47-card {
    background: white;
    border: 1px solid #ccd0d4;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.agent-47-card.full-width {
    grid-column: 1 / -1;
}

.agent-47-card h2 {
    margin-top: 0;
    margin-bottom: 15px;
    color: #23282d;
    font-size: 18px;
}

.status-grid, .stats-grid, .metrics-grid {
    display: grid;
    gap: 10px;
}

.status-item, .metric-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
    border-bottom: 1px solid #f0f0f1;
}

.status-item:last-child, .metric-item:last-child {
    border-bottom: none;
}

.status-label, .metric-label {
    font-weight: 500;
    color: #50575e;
}

.status-value, .metric-value {
    font-weight: 600;
    color: #23282d;
}

.status-value.warning {
    color: #dba617;
}

.status-value.normal {
    color: #00a32a;
}

.stats-grid {
    grid-template-columns: repeat(2, 1fr);
}

.stat-item {
    text-align: center;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 6px;
}

.stat-number {
    font-size: 24px;
    font-weight: 700;
    color: #23282d;
    margin-bottom: 5px;
}

.stat-label {
    font-size: 12px;
    color: #50575e;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.health-grid {
    display: flex;
    align-items: center;
}

.health-indicator {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px;
    border-radius: 6px;
    background: #f8f9fa;
}

.health-indicator.good {
    background: #d1e7dd;
    color: #0f5132;
}

.health-indicator.warning {
    background: #fff3cd;
    color: #664d03;
}

.health-indicator.critical {
    background: #f8d7da;
    color: #721c24;
}

.health-dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: currentColor;
}

.health-text {
    font-weight: 500;
}

#real-time-stats {
    min-height: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f8f9fa;
    border-radius: 6px;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Real-time updates every 30 seconds
    function updateRealTimeStats() {
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'get_chatbot_stats',
                nonce: '<?php echo esc_js(wp_create_nonce('chatbot_stats_nonce')); ?>'
            },
            success: function(response) {
                if (response.success) {
                    $('#real-time-stats').html(response.data.html);
                }
            }
        });
    }
    
    // Update every 30 seconds
    setInterval(updateRealTimeStats, 30000);
    
    // Initial update
    updateRealTimeStats();
});
</script> 