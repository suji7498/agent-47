/**
 * Admin JavaScript for Agent-47
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Test webhook functionality
        $('#test-webhook-btn').on('click', function() {
            const button = $(this);
            const resultDiv = $('#test-result');
            
            // Disable button and show loading
            button.prop('disabled', true).text('Testing...');
            resultDiv.html('<div class="notice notice-info"><p>🔄 Testing webhook connection...</p></div>');
            
            // Get webhook URL and HTTP method from form
            const webhookUrl = $('#n8n_webhook_url').val();
            const httpMethod = $('#webhook_http_method').val() || 'POST';
            
            if (!webhookUrl) {
                resultDiv.html('<div class="notice notice-error"><p>❌ Please enter a webhook URL first.</p></div>');
                button.prop('disabled', false).text('Test Connection');
                return;
            }
            
            // Debug: Check if nonce is available
            if (typeof chatbot_admin_nonce === 'undefined') {
                resultDiv.html('<div class="notice notice-error"><p>❌ Security token not available. Please refresh the page.</p></div>');
                button.prop('disabled', false).text('Test Connection');
                return;
            }
            
            // Send test request
            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'test_webhook',
                    webhook_url: webhookUrl,
                    http_method: httpMethod,
                    nonce: chatbot_admin_nonce
                },
                success: function(response) {
                    if (response.success) {
                        resultDiv.html('<div class="notice notice-success"><p>✅ ' + response.data + '</p></div>');
                    } else {
                        resultDiv.html('<div class="notice notice-error"><p>❌ ' + response.data + '</p></div>');
                    }
                },
                error: function(xhr, status, error) {
                    let errorMessage = 'Failed to test webhook. Please check your connection.';
                    if (xhr.responseJSON && xhr.responseJSON.data) {
                        errorMessage = xhr.responseJSON.data;
                    }
                    resultDiv.html('<div class="notice notice-error"><p>❌ ' + errorMessage + '</p></div>');
                },
                complete: function() {
                    button.prop('disabled', false).text('Test Connection');
                }
            });
        });
        
        // Auto-save webhook URL when testing
        $('#n8n_webhook_url').on('blur', function() {
            const url = $(this).val();
            if (url && isValidUrl(url)) {
                $(this).addClass('valid-url').removeClass('invalid-url');
            } else if (url) {
                $(this).addClass('invalid-url').removeClass('valid-url');
            } else {
                $(this).removeClass('valid-url invalid-url');
            }
        });
        
        // URL validation helper
        function isValidUrl(string) {
            try {
                new URL(string);
                return true;
            } catch (_) {
                return false;
            }
        }
        
        // Settings validation and save feedback
        $('form').on('submit', function(e) {
            const webhookUrl = $('#n8n_webhook_url').val();
            const chatbotTitle = $('#chatbot_title').val();
            
            let hasErrors = false;
            
            // Clear previous error messages
            $('.field-error').remove();
            
            // Validate webhook URL
            if (webhookUrl && !isValidUrl(webhookUrl)) {
                $('#n8n_webhook_url').after('<span class="field-error">Please enter a valid URL</span>');
                hasErrors = true;
            }
            
            // Validate chatbot title
            if (!chatbotTitle.trim()) {
                $('#chatbot_title').after('<span class="field-error">Please enter a chatbot title</span>');
                hasErrors = true;
            }
            
            if (hasErrors) {
                e.preventDefault();
                $('html, body').animate({
                    scrollTop: $('.field-error').first().offset().top - 100
                }, 500);
            } else {
                // Show saving feedback
                const submitButton = $(this).find('input[type="submit"]');
                const originalText = submitButton.val();
                submitButton.val('Saving...').prop('disabled', true);
                
                // Re-enable after a short delay (in case of validation errors)
                setTimeout(function() {
                    submitButton.val(originalText).prop('disabled', false);
                }, 3000);
            }
        });
        
        // Show/hide auth token field based on webhook URL
        $('#n8n_webhook_url').on('input', function() {
            const url = $(this).val();
            const authField = $('#webhook_auth_token').closest('tr');
            
            if (url && url.includes('https://')) {
                authField.show();
            } else {
                authField.hide();
            }
        }).trigger('input');
        
        // Initialize tooltips for help text
        $('.description').each(function() {
            const helpText = $(this).text();
            if (helpText.length > 100) {
                $(this).addClass('help-tooltip');
                $(this).attr('title', helpText);
            }
        });
        
        // Add some visual feedback for form interactions
        $('input, select, textarea').on('focus', function() {
            $(this).closest('tr').addClass('focused');
        }).on('blur', function() {
            $(this).closest('tr').removeClass('focused');
        });
        
        // Auto-resize textarea
        $('#webhook_auth_token').on('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
        
        // Settings import/export functionality (if needed)
        $('#export-settings').on('click', function(e) {
            e.preventDefault();
            
            const settings = {
                n8n_webhook_url: $('#n8n_webhook_url').val(),
                webhook_auth_token: $('#webhook_auth_token').val(),
                chatbot_title: $('#chatbot_title').val(),
                chatbot_enabled: $('#chatbot_enabled').is(':checked'),
                chat_position: $('#chat_position').val()
            };
            
            const dataStr = JSON.stringify(settings, null, 2);
            const dataBlob = new Blob([dataStr], {type: 'application/json'});
            
            const link = document.createElement('a');
            link.href = URL.createObjectURL(dataBlob);
            link.download = 'agent-47-settings.json';
            link.click();
        });
        
        // Settings import
        $('#import-settings').on('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const settings = JSON.parse(e.target.result);
                    
                    // Populate form fields
                    $('#n8n_webhook_url').val(settings.n8n_webhook_url || '');
                    $('#webhook_auth_token').val(settings.webhook_auth_token || '');
                    $('#chatbot_title').val(settings.chatbot_title || '');
                    $('#chatbot_enabled').prop('checked', settings.chatbot_enabled !== false);
                    $('#chat_position').val(settings.chat_position || 'bottom-right');
                    $('#chatbot_theme').val(settings.chatbot_theme || 'skyblue');
                    
                    // Trigger validation and theme preview
                    $('#n8n_webhook_url').trigger('blur');
                    updateThemePreview();
                    
                    alert('Settings imported successfully! Click "Save Settings" to apply them.');
                    
                } catch (error) {
                    alert('Error importing settings: Invalid file format');
                }
            };
            reader.readAsText(file);
        });
        
        // Theme preview functionality
        function updateThemePreview() {
            const selectedTheme = $('#chatbot_theme').val();
            $('.theme-preview-box').removeClass('active');
            $('.theme-preview-box[data-theme="' + selectedTheme + '"]').addClass('active');
        }
        
        // Initialize theme preview
        updateThemePreview();
        
        // Update theme preview when selection changes
        $('#chatbot_theme').on('change', updateThemePreview);
        
        // Click on theme preview boxes to change selection
        $('.theme-preview-box').on('click', function() {
            const theme = $(this).data('theme');
            $('#chatbot_theme').val(theme).trigger('change');
        });
        
        // Debug: Log theme preview initialization
        console.log('Agent-47: Theme preview initialized. Found', $('.theme-preview-box').length, 'theme boxes');
        
        // Debug: Check if admin nonce is available
        if (typeof chatbot_admin_nonce !== 'undefined') {
            console.log('Agent-47: Admin nonce available');
        } else {
            console.log('Agent-47: Admin nonce NOT available');
        }
        
    });
    
})(jQuery); 