<?php
/**
 * Security and sanitization functions
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Chatbot_N8N_Security {
    
    /**
     * Sanitize chat message
     * 
     * @param string $message Raw message
     * @return string Sanitized message
     */
    public static function sanitize_message($message) {
        
        // Remove dangerous HTML and scripts
        $message = wp_kses($message, array(
            'br' => array(),
            'em' => array(),
            'strong' => array(),
            'b' => array(),
            'i' => array()
        ));
        
        // Sanitize text field
        $message = sanitize_textarea_field($message);
        
        // Trim whitespace
        $message = trim($message);
        
        // Limit message length
        if (strlen($message) > 1000) {
            $message = substr($message, 0, 1000);
        }
        
        return $message;
    }
    
    /**
     * Validate session ID
     * 
     * @param string $session_id Session ID to validate
     * @return bool True if valid
     */
    public static function validate_session_id($session_id) {
        return preg_match('/^chat_[a-zA-Z0-9_]+$/', $session_id);
    }
    
    /**
     * Generate secure nonce for AJAX requests
     * 
     * @param string $action Action name
     * @return string Nonce
     */
    public static function generate_nonce($action = 'chatbot_action') {
        return wp_create_nonce($action);
    }
    
    /**
     * Verify nonce for AJAX requests
     * 
     * @param string $nonce Nonce to verify
     * @param string $action Action name
     * @return bool True if valid
     */
    public static function verify_nonce($nonce, $action = 'chatbot_action') {
        return wp_verify_nonce($nonce, $action);
    }
    
    /**
     * Rate limiting check
     * 
     * @param string $user_identifier User IP or ID
     * @param int $max_requests Maximum requests per minute
     * @return bool True if within limits
     */
    public static function check_rate_limit($user_identifier, $max_requests = 30) {
        
        $transient_key = 'chatbot_rate_limit_' . md5($user_identifier);
        $current_requests = get_transient($transient_key);
        
        if ($current_requests === false) {
            set_transient($transient_key, 1, MINUTE_IN_SECONDS);
            return true;
        }
        
        if ($current_requests >= $max_requests) {
            return false;
        }
        
        set_transient($transient_key, $current_requests + 1, MINUTE_IN_SECONDS);
        return true;
    }
    
    /**
     * Sanitize webhook URL
     * 
     * @param string $url URL to sanitize
     * @return string Sanitized URL
     */
    public static function sanitize_webhook_url($url) {
        return esc_url_raw($url);
    }
} 