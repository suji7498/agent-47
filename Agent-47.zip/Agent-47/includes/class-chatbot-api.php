<?php
/**
 * REST API endpoints for chatbot
 */

if (!defined('ABSPATH')) {
    exit;
}

class Agent_47_API {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }
    
    /**
     * Register REST API routes
     */
    public function register_routes() {
        
        // Send message endpoint
        register_rest_route('agent-47/v1', '/message', array(
            'methods' => 'POST',
            'callback' => array($this, 'send_message'),
            'permission_callback' => array($this, 'check_permissions'),
            'args' => array(
                'message' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field'
                ),
                'session_id' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field'
                )
            )
        ));
        
        // Get chat history endpoint
        register_rest_route('agent-47/v1', '/history/(?P<session_id>[a-zA-Z0-9_]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_history'),
            'permission_callback' => array($this, 'check_permissions')
        ));
        
        // Health check endpoint
        register_rest_route('agent-47/v1', '/health', array(
            'methods' => 'GET',
            'callback' => array($this, 'health_check'),
            'permission_callback' => '__return_true'
        ));
    }
    
    /**
     * Send message to chatbot
     * 
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response Response
     */
    public function send_message($request) {
        
        $message = $request->get_param('message');
        $session_id = $request->get_param('session_id');
        
        // Process the message
        $response = Agent_47_Core::process_message($message, $session_id);
        
        if ($response['success']) {
            return rest_ensure_response(array(
                'success' => true,
                'data' => array(
                    'message' => $response['message'],
                    'session_id' => $response['session_id'],
                    'timestamp' => current_time('mysql')
                )
            ));
        }
        
        return new WP_Error(
            'chatbot_error',
            $response['message'],
            array('status' => 500)
        );
    }
    
    /**
     * Get chat history
     * 
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response Response
     */
    public function get_history($request) {
        
        $session_id = $request->get_param('session_id');
        $limit = $request->get_param('limit') ?: 50;
        
        $history = Agent_47_Core::get_chat_history($session_id, $limit);
        
        return rest_ensure_response(array(
            'success' => true,
            'data' => $history
        ));
    }
    
    /**
     * Health check endpoint
     * 
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response Response
     */
    public function health_check($request) {
        
        $settings = get_option('agent_47_settings', array());
        $webhook_configured = !empty($settings['n8n_webhook_url']);
        
        return rest_ensure_response(array(
            'success' => true,
            'data' => array(
                'plugin_version' => AGENT_47_VERSION,
                'webhook_configured' => $webhook_configured,
                'timestamp' => current_time('mysql')
            )
        ));
    }
    
    /**
     * Check API permissions
     * 
     * @param WP_REST_Request $request Request object
     * @return bool Permission granted
     */
    public function check_permissions($request) {
        
        // Check nonce for security
        $nonce = $request->get_header('X-WP-Nonce');
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return false;
        }
        
        // For now, allow all authenticated users
        // You can add more specific permission checks here
        return true;
    }
} 