<?php
/**
 * Core chatbot functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

class Agent_47_Core {
    
    // Add concurrency control constants
    const MAX_CONCURRENT_SESSIONS = 200;
    const SESSION_TIMEOUT = 1800; // 30 minutes
    const RATE_LIMIT_PER_MINUTE = 60;
    
    /**
     * Process incoming message
     */
    public static function process_message($message, $session_id = null) {
        try {
            // Check concurrency limits
            if (!self::check_concurrency_limits()) {
                return array(
                    'success' => false,
                    'message' => 'Server is currently busy. Please try again in a moment.',
                    'session_id' => $session_id
                );
            }
            
            // Validate and sanitize message
            $message = sanitize_textarea_field($message);
            if (empty($message)) {
                return array(
                    'success' => false,
                    'message' => 'Empty message received',
                    'session_id' => $session_id
                );
            }
            
            // Generate session ID if not provided
            if (!$session_id) {
                $session_id = self::generate_session_id();
            }
            
            // Check rate limiting per session
            if (!self::check_session_rate_limit($session_id)) {
                return array(
                    'success' => false,
                    'message' => 'Too many messages. Please wait a moment.',
                    'session_id' => $session_id
                );
            }
            
            // Store session data
            self::store_session_data($session_id, $message);
            
            // Get AI response
            $response = self::get_ai_response($message, $session_id);
            
            return array(
                'success' => true,
                'message' => $response,
                'session_id' => $session_id
            );
            
        } catch (Exception $e) {
            // error_log('Agent-47 Core Error: ' . $e->getMessage());
            return array(
                'success' => false,
                'message' => 'An error occurred. Please try again.',
                'session_id' => $session_id
            );
        }
    }
    
    /**
     * Check concurrency limits
     */
    private static function check_concurrency_limits() {
        $active_sessions = self::get_active_sessions_count();
        return $active_sessions < self::MAX_CONCURRENT_SESSIONS;
    }
    
    /**
     * Get count of active sessions
     */
    private static function get_active_sessions_count() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'agent_47_sessions';
        
        // Clean up expired sessions first
        self::cleanup_expired_sessions();
        
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table_name} WHERE last_activity > %d",
            time() - self::SESSION_TIMEOUT
        ));
        
        return (int) $count;
    }
    
    /**
     * Check rate limiting per session
     */
    private static function check_session_rate_limit($session_id) {
        $rate_limit_key = 'agent_47_rate_limit_' . $session_id;
        $current_count = get_transient($rate_limit_key);
        
        if ($current_count === false) {
            set_transient($rate_limit_key, 1, 60); // 1 minute
            return true;
        }
        
        if ($current_count >= self::RATE_LIMIT_PER_MINUTE) {
            return false;
        }
        
        set_transient($rate_limit_key, $current_count + 1, 60);
        return true;
    }
    
    /**
     * Clean up expired sessions
     */
    private static function cleanup_expired_sessions() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'agent_47_sessions';
        
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$table_name} WHERE last_activity < %d",
            time() - self::SESSION_TIMEOUT
        ));
    }
    
    /**
     * Store session data
     */
    private static function store_session_data($session_id, $message) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'agent_47_sessions';
        
        // Get current message count
        $current_count = $wpdb->get_var($wpdb->prepare(
            "SELECT message_count FROM {$table_name} WHERE session_id = %s",
            $session_id
        ));
        
        $message_count = $current_count ? $current_count + 1 : 1;
        
        $wpdb->replace(
            $table_name,
            array(
                'session_id' => $session_id,
                'last_activity' => time(),
                'message_count' => $message_count,
                'user_ip' => self::get_client_ip(),
                'user_agent' => sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? ''))
            ),
            array('%s', '%d', '%d', '%s', '%s')
        );
        
        // Debug logging (remove in production)
        // error_log('Agent-47: Stored session data - Session: ' . $session_id . ', Message count: ' . $message_count);
    }
    
    /**
     * Get AI response with concurrency handling
     */
    private static function get_ai_response($message, $session_id) {
        $settings = get_option('agent_47_settings', array());
        $webhook_url = $settings['n8n_webhook_url'] ?? '';
        
        if (empty($webhook_url)) {
            return 'Webhook URL not configured. Please contact administrator.';
        }
        
        // Use the webhook class for consistent handling
        $webhook = new Agent_47_Webhook();
        
        // Debug logging (remove in production)
        // error_log('Agent-47: Sending request to webhook - Message: ' . substr($message, 0, 50) . '... Session: ' . $session_id);
        
        // Send message via webhook class
        $response = $webhook->send_message($message, $session_id);
        
        // Debug logging (remove in production)
        if ($response && isset($response['message'])) {
            // error_log('Agent-47: Received response from webhook - Response: ' . substr($response['message'], 0, 100) . '...');
            return $response['message'];
        } else {
            // error_log('Agent-47: No valid response from webhook');
            return 'Sorry, I\'m having trouble connecting right now. Please try again in a moment.';
        }
    }
    
    /**
     * Make API request with concurrency handling
     */
    private static function make_api_request($url, $data) {
        $timeout = 30; // 30 seconds timeout
        $max_retries = 2;
        
        for ($attempt = 0; $attempt <= $max_retries; $attempt++) {
            $response = wp_remote_post($url, array(
                'timeout' => $timeout,
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'User-Agent' => 'Agent-47-Chatbot/1.0'
                ),
                'body' => json_encode($data),
                'data_format' => 'body'
            ));
            
            if (!is_wp_error($response)) {
                $body = wp_remote_retrieve_body($response);
                $response_code = wp_remote_retrieve_response_code($response);
                
                if ($response_code === 200) {
                    $decoded = json_decode($body, true);
                    
                    // Debug logging (remove in production)
                    // error_log('Agent-47: Webhook response decoded - ' . json_encode($decoded));
                    
                    // Handle different response formats
                    $response_text = '';
                    if (isset($decoded['response'])) {
                        $response_text = $decoded['response'];
                    } elseif (isset($decoded['message'])) {
                        $response_text = $decoded['message'];
                    } elseif (isset($decoded['output'])) {
                        $response_text = $decoded['output'];
                    } elseif (is_string($decoded)) {
                        $response_text = $decoded;
                    } else {
                        $response_text = 'Response received successfully.';
                    }
                    
                    return $response_text;
                }
                
                // Handle rate limiting
                if ($response_code === 429) {
                    $retry_after = wp_remote_retrieve_header($response, 'Retry-After');
                    $wait_time = $retry_after ? (int) $retry_after : 5;
                    sleep($wait_time);
                    continue;
                }
            }
            
            // Wait before retry
            if ($attempt < $max_retries) {
                sleep(1);
            }
        }
        
        return 'Sorry, I\'m having trouble connecting right now. Please try again in a moment.';
    }
    

    
    /**
     * Generate unique session ID
     */
    private static function generate_session_id() {
        return 'session_' . time() . '_' . wp_generate_password(8, false);
    }
    
    /**
     * Get client IP address
     */
    private static function get_client_ip() {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', wp_unslash($_SERVER[$key])) as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return wp_unslash($_SERVER['REMOTE_ADDR'] ?? '');
    }
    
    /**
     * Get system status for monitoring
     */
    public static function get_system_status() {
        $active_sessions = self::get_active_sessions_count();
        $memory_usage = memory_get_usage(true);
        $memory_limit = ini_get('memory_limit');
        
        return array(
            'active_sessions' => $active_sessions,
            'max_concurrent_sessions' => self::MAX_CONCURRENT_SESSIONS,
            'memory_usage' => $memory_usage,
            'memory_limit' => $memory_limit,
            'session_timeout' => self::SESSION_TIMEOUT,
            'rate_limit_per_minute' => self::RATE_LIMIT_PER_MINUTE
        );
    }
} 