<?php
/**
 * Core chatbot functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

class Agent_47_Core {
    
    /**
     * Process chat message
     * 
     * @param string $message User message
     * @param string $session_id Chat session ID
     * @return array Response from n8n workflow
     */
    public static function process_message($message, $session_id = null) {
        
        // Sanitize input
        $message = Agent_47_Security::sanitize_message($message);
        
        if (empty($message)) {
            return array(
                'success' => false,
                'message' => __('Empty message received', 'agent-47')
            );
        }
        
        // Generate session ID if not provided
        if (!$session_id) {
            $session_id = self::generate_session_id();
        }
        
        // Store message in database
        $database = new Agent_47_Database();
        $database->store_message($session_id, $message, 'user');
        
        // Check for introductory greetings first
        $greeting_response = self::handle_introductory_greetings($message);
        if ($greeting_response) {
            $database->store_message($session_id, $greeting_response, 'bot');
            return array(
                'success' => true,
                'message' => $greeting_response,
                'session_id' => $session_id
            );
        }
        
        // Get settings to check if webhook is configured
        $settings = get_option('agent_47_settings', array());
        $webhook_url = $settings['n8n_webhook_url'] ?? '';
        
        // If webhook is not configured, try local search
        if (empty($webhook_url)) {
            $local_response = self::handle_local_search($message);
            if ($local_response) {
                $database->store_message($session_id, $local_response, 'bot');
                return array(
                    'success' => true,
                    'message' => $local_response,
                    'session_id' => $session_id
                );
            }
        }
        
        // Send to n8n webhook
        $webhook = new Agent_47_Webhook();
        $response = $webhook->send_message($message, $session_id);
        
        if ($response && isset($response['message'])) {
            // Store bot response
            $database->store_message($session_id, $response['message'], 'bot');
            
            return array(
                'success' => true,
                'message' => $response['message'],
                'session_id' => $session_id
            );
        }
        
        // If webhook fails and no local response, provide fallback
        if (empty($webhook_url)) {
            $fallback_response = self::get_fallback_response($message);
            $database->store_message($session_id, $fallback_response, 'bot');
            return array(
                'success' => true,
                'message' => $fallback_response,
                'session_id' => $session_id
            );
        }
        
        return array(
            'success' => false,
            'message' => __('Failed to get response from AI agent', 'agent-47')
        );
    }
    
    /**
     * Generate unique session ID
     * 
     * @return string Session ID
     */
    public static function generate_session_id() {
        return 'chat_' . uniqid() . '_' . time();
    }
    
    /**
     * Get chat history
     * 
     * @param string $session_id Session ID
     * @param int $limit Number of messages to retrieve
     * @return array Chat history
     */
    public static function get_chat_history($session_id, $limit = 50) {
        $database = new Agent_47_Database();
        return $database->get_chat_history($session_id, $limit);
    }
    
    /**
     * Validate n8n webhook URL
     * 
     * @param string $url Webhook URL
     * @return bool True if valid
     */
    public static function validate_webhook_url($url) {
        return filter_var($url, FILTER_VALIDATE_URL) && 
               (strpos($url, 'http://') === 0 || strpos($url, 'https://') === 0);
    }
    
    /**
     * Handle introductory greetings
     * 
     * @param string $message User message
     * @return string|false Response message or false if not a greeting
     */
    public static function handle_introductory_greetings($message) {
        $greetings = array(
            'hi', 'hello', 'hey', 'good morning', 'good afternoon', 
            'good evening', 'greetings', 'hi there', 'hello there'
        );
        
        $message_lower = strtolower(trim($message));
        
        foreach ($greetings as $greeting) {
            if (strpos($message_lower, $greeting) === 0) {
                $responses = array(
                    __('Hi there! 👋 How can I help you today?', 'agent-47'),
                    __('Hello! 😊 Welcome to our website. What can I assist you with?', 'agent-47'),
                    __('Hey! 👋 Great to see you here. How may I help?', 'agent-47'),
                    __('Hi! 😄 Thanks for stopping by. What would you like to know?', 'agent-47'),
                    __('Hello there! 👋 I\'m here to help. What can I do for you?', 'agent-47')
                );
                
                return $responses[array_rand($responses)];
            }
        }
        
        return false;
    }
    
    /**
     * Handle local responses when no webhook is connected
     * 
     * @param string $message User message
     * @return string|false Response message or false if no relevant info found
     */
    public static function handle_local_search($message) {
        $message_lower = strtolower($message);
        
        // Check for additional greetings and casual conversation
        $casual_greetings = array(
            'how are you', 'how r u', 'how do you do', 'what\'s up', 'whats up', 
            'sup', 'how\'s it going', 'hows it going', 'how is it going',
            'good morning', 'good afternoon', 'good evening', 'good night',
            'nice to meet you', 'pleasure to meet you'
        );
        
        foreach ($casual_greetings as $greeting) {
            if (strpos($message_lower, $greeting) !== false) {
                $responses = array(
                    __('I\'m doing great, thank you for asking! 😊 How can I help you today?', 'agent-47'),
                    __('I\'m fine, thanks! 😄 Is there anything I can assist you with?', 'agent-47'),
                    __('I\'m well, thank you! 👋 What can I do for you?', 'agent-47'),
                    __('All good here! 😊 How may I help you?', 'agent-47'),
                    __('I\'m excellent, thanks for asking! 😄 What would you like to know?', 'agent-47')
                );
                
                return $responses[array_rand($responses)];
            }
        }
        
        // For any other questions, provide contact form message
        $site_url = get_bloginfo('url');
        $contact_page = get_page_by_path('contact');
        
        if ($contact_page) {
            $contact_url = $site_url . '/contact';
        } else {
            $contact_url = $site_url;
        }
        
        $response = sprintf(
            __('Sorry, there is some issue while helping you. Please use our contact form at %s for assistance.', 'agent-47'),
            $contact_url
        );
        
        return $response;
    }
    
    /**
     * Get fallback response when no specific handler matches
     * 
     * @param string $message User message
     * @return string Fallback response
     */
    public static function get_fallback_response($message) {
        $fallback_responses = array(
            __('I\'m here to help! Could you please rephrase your question or ask about our website, services, or contact information?', 'agent-47'),
            __('I\'d be happy to assist you. You can ask me about our company, services, or how to contact us.', 'agent-47'),
            __('Let me help you find what you\'re looking for. What would you like to know about our business?', 'agent-47'),
            __('I\'m here to provide information about our website and services. How can I help you today?', 'agent-47'),
            __('Feel free to ask me about our company, what we do, or how to get in touch with us.', 'agent-47')
        );
        
        return $fallback_responses[array_rand($fallback_responses)];
    }
} 