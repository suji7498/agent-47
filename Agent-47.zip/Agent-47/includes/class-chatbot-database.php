<?php
/**
 * Database operations for Agent-47 chatbot
 */

if (!defined('ABSPATH')) {
    exit;
}

class Agent_47_Database {
    
    /**
     * Create database tables
     */
    public static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Sessions table for concurrency management
        $sessions_table = $wpdb->prefix . 'agent_47_sessions';
        $sessions_sql = "CREATE TABLE $sessions_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(255) NOT NULL,
            last_activity int(11) NOT NULL,
            message_count int(11) DEFAULT 1,
            user_ip varchar(45) DEFAULT '',
            user_agent text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY session_id (session_id),
            KEY last_activity (last_activity),
            KEY user_ip (user_ip)
        ) $charset_collate;";
        
        // Messages table for individual messages
        $messages_table = $wpdb->prefix . 'agent_47_messages';
        $messages_sql = "CREATE TABLE $messages_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(255) NOT NULL,
            message text NOT NULL,
            sender enum('user', 'bot') NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY sender (sender),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // Rate limiting table
        $rate_limits_table = $wpdb->prefix . 'agent_47_rate_limits';
        $rate_limits_sql = "CREATE TABLE $rate_limits_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            identifier varchar(255) NOT NULL,
            request_count int(11) DEFAULT 1,
            first_request int(11) NOT NULL,
            last_request int(11) NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY identifier (identifier),
            KEY first_request (first_request),
            KEY last_request (last_request)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        dbDelta($sessions_sql);
        dbDelta($messages_sql);
        dbDelta($rate_limits_sql);
        
        // Add version option
        add_option('agent_47_db_version', '1.3.1');
    }
    
    /**
     * Store message in database
     */
    public function store_message($session_id, $message, $sender) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'agent_47_messages';
        
        return $wpdb->insert(
            $table_name,
            array(
                'session_id' => $session_id,
                'message' => $message,
                'sender' => $sender,
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s')
        );
    }
    
    /**
     * Get chat history
     */
    public function get_chat_history($session_id, $limit = 50) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'agent_47_messages';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} 
             WHERE session_id = %s 
             ORDER BY created_at ASC 
             LIMIT %d",
            $session_id,
            $limit
        ));
    }
    
    /**
     * Get active sessions count
     */
    public function get_active_sessions_count($timeout = 1800) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'agent_47_sessions';
        
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table_name} WHERE last_activity > %d",
            time() - $timeout
        ));
    }
    
    /**
     * Update session activity
     */
    public function update_session_activity($session_id, $user_ip = '', $user_agent = '') {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'agent_47_sessions';
        
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE session_id = %s",
            $session_id
        ));
        
        if ($existing) {
            // Update existing session
            return $wpdb->update(
                $table_name,
                array(
                    'last_activity' => time(),
                    'message_count' => $existing->message_count + 1,
                    'user_ip' => $user_ip,
                    'user_agent' => $user_agent
                ),
                array('session_id' => $session_id),
                array('%d', '%d', '%s', '%s'),
                array('%s')
            );
        } else {
            // Create new session
            return $wpdb->insert(
                $table_name,
                array(
                    'session_id' => $session_id,
                    'last_activity' => time(),
                    'message_count' => 1,
                    'user_ip' => $user_ip,
                    'user_agent' => $user_agent,
                    'created_at' => current_time('mysql')
                ),
                array('%s', '%d', '%d', '%s', '%s', '%s')
            );
        }
    }
    
    /**
     * Clean up expired sessions
     */
    public function cleanup_expired_sessions($timeout = 1800) {
        global $wpdb;
        
        $sessions_table = $wpdb->prefix . 'agent_47_sessions';
        $messages_table = $wpdb->prefix . 'agent_47_messages';
        
        // Get expired session IDs
        $expired_sessions = $wpdb->get_col($wpdb->prepare(
            "SELECT session_id FROM {$sessions_table} WHERE last_activity < %d",
            time() - $timeout
        ));
        
        if (!empty($expired_sessions)) {
            $placeholders = implode(',', array_fill(0, count($expired_sessions), '%s'));
            
            // Delete from sessions table
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$sessions_table} WHERE session_id IN ($placeholders)",
                $expired_sessions
            ));
            
            // Delete from messages table
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$messages_table} WHERE session_id IN ($placeholders)",
                $expired_sessions
            ));
        }
        
        return count($expired_sessions);
    }
    
    /**
     * Get system statistics
     */
    public function get_system_stats() {
        global $wpdb;
        
        $sessions_table = $wpdb->prefix . 'agent_47_sessions';
        $messages_table = $wpdb->prefix . 'agent_47_messages';
        
        $stats = array();
        
        // Total sessions today
        $stats['sessions_today'] = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$sessions_table} WHERE DATE(created_at) = %s",
            current_time('Y-m-d')
        ));
        
        // Active sessions
        $stats['active_sessions'] = $this->get_active_sessions_count();
        
        // Total messages today
        $stats['messages_today'] = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$messages_table} WHERE DATE(created_at) = %s",
            current_time('Y-m-d')
        ));
        
        // Average messages per session
        $stats['avg_messages_per_session'] = $wpdb->get_var(
            "SELECT AVG(message_count) FROM {$sessions_table}"
        );
        
        return $stats;
    }
    
    /**
     * Get performance metrics
     */
    public function get_performance_metrics() {
        global $wpdb;
        
        $sessions_table = $wpdb->prefix . 'agent_47_sessions';
        
        $metrics = array();
        
        // Peak concurrent sessions (last 24 hours)
        $metrics['peak_concurrent_24h'] = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT MAX(session_count) FROM (
                SELECT COUNT(*) as session_count 
                FROM {$sessions_table} 
                WHERE last_activity > %d 
                GROUP BY FLOOR(last_activity / 300)
            ) as hourly_counts",
            time() - 86400
        ));
        
        // Average response time (if we track it)
        $metrics['avg_response_time'] = 0; // Would need to implement response time tracking
        
        return $metrics;
    }
} 