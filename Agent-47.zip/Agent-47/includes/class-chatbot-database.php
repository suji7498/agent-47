<?php
/**
 * Database operations handler
 */

if (!defined('ABSPATH')) {
    exit;
}

class Agent_47_Database {
    
    /**
     * Create database tables
     */
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Chat sessions table
        $sessions_table = $wpdb->prefix . 'chatbot_sessions';
        $sessions_sql = "CREATE TABLE $sessions_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(255) NOT NULL,
            user_id bigint(20) DEFAULT 0,
            ip_address varchar(45) DEFAULT '',
            user_agent text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY session_id (session_id),
            KEY user_id (user_id),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // Chat messages table
        $messages_table = $wpdb->prefix . 'chatbot_messages';
        $messages_sql = "CREATE TABLE $messages_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(255) NOT NULL,
            message text NOT NULL,
            sender enum('user', 'bot') NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY sender (sender),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sessions_sql);
        dbDelta($messages_sql);
    }
    
    /**
     * Store a message in the database
     * 
     * @param string $session_id Session ID
     * @param string $message Message content
     * @param string $sender 'user' or 'bot'
     * @return bool Success status
     */
    public function store_message($session_id, $message, $sender) {
        global $wpdb;
        
        $messages_table = $wpdb->prefix . 'chatbot_messages';
        
        $result = $wpdb->insert(
            $messages_table,
            array(
                'session_id' => $session_id,
                'message' => $message,
                'sender' => $sender
            ),
            array('%s', '%s', '%s')
        );
        
        if ($result === false) {
            error_log('Agent-47: Failed to store message - ' . $wpdb->last_error);
            return false;
        }
        
        // Update or create session record
        $this->update_session($session_id);
        
        return true;
    }
    
    /**
     * Get chat history for a session
     * 
     * @param string $session_id Session ID
     * @param int $limit Number of messages to retrieve
     * @return array Chat history
     */
    public function get_chat_history($session_id, $limit = 50) {
        global $wpdb;
        
        $messages_table = $wpdb->prefix . 'chatbot_messages';
        
        $query = $wpdb->prepare(
            "SELECT message, sender, created_at 
             FROM $messages_table 
             WHERE session_id = %s 
             ORDER BY created_at ASC 
             LIMIT %d",
            $session_id,
            $limit
        );
        
        $results = $wpdb->get_results($query, ARRAY_A);
        
        if ($results === null) {
            error_log('Agent-47: Failed to retrieve chat history - ' . $wpdb->last_error);
            return array();
        }
        
        return $results;
    }
    
    /**
     * Update or create session record
     * 
     * @param string $session_id Session ID
     * @return bool Success status
     */
    private function update_session($session_id) {
        global $wpdb;
        
        $sessions_table = $wpdb->prefix . 'chatbot_sessions';
        
        // Check if session exists
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $sessions_table WHERE session_id = %s",
            $session_id
        ));
        
        if ($existing) {
            // Update existing session
            $result = $wpdb->update(
                $sessions_table,
                array('updated_at' => current_time('mysql')),
                array('session_id' => $session_id),
                array('%s'),
                array('%s')
            );
        } else {
            // Create new session
            $result = $wpdb->insert(
                $sessions_table,
                array(
                    'session_id' => $session_id,
                    'user_id' => get_current_user_id(),
                    'ip_address' => $this->get_client_ip(),
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
                ),
                array('%s', '%d', '%s', '%s')
            );
        }
        
        return $result !== false;
    }
    
    /**
     * Get client IP address
     * 
     * @return string IP address
     */
    private function get_client_ip() {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '';
    }
    
    /**
     * Clean up old sessions and messages
     * 
     * @param int $days_old Number of days to keep
     * @return int Number of records deleted
     */
    public function cleanup_old_data($days_old = 30) {
        global $wpdb;
        
        $cutoff_date = date('Y-m-d H:i:s', strtotime("-{$days_old} days"));
        
        // Delete old messages
        $messages_table = $wpdb->prefix . 'chatbot_messages';
        $messages_deleted = $wpdb->query($wpdb->prepare(
            "DELETE FROM $messages_table WHERE created_at < %s",
            $cutoff_date
        ));
        
        // Delete old sessions
        $sessions_table = $wpdb->prefix . 'chatbot_sessions';
        $sessions_deleted = $wpdb->query($wpdb->prepare(
            "DELETE FROM $sessions_table WHERE updated_at < %s",
            $cutoff_date
        ));
        
        return $messages_deleted + $sessions_deleted;
    }
} 