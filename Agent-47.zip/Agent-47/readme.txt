=== Agent-47 ===
Contributors: surajjadhao
Tags: chatbot, n8n, automation, ai, webhook
Requires at least: 5.8
Tested up to: 6.8
Stable tag: 1.3.1
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create intelligent chatbots for WordPress using n8n workflows and AI services.

![Agent-47 Logo](https://raw.githubusercontent.com/surajjadhao/agent-47/main/assets/Agent-47_Logo.png)

== Description ==

**Agent-47** is a powerful and flexible plugin that allows you to create intelligent chatbots for your WordPress website by integrating with n8n workflows.

= Key Features =

* 🤖 **Flexible n8n Integration**: Works with any n8n workflow
* 🎨 **Customizable UI**: 5 different themes and multiple positions
* 🔧 **Easy Setup**: Simple configuration and testing tools
* 📱 **Responsive Design**: Works on desktop and mobile
* 🔒 **Secure**: Built-in security features and authentication support
* 🐛 **Debug Tools**: Comprehensive debugging and testing utilities

= Use Cases =

* **AI Chatbots**: Integrate with AI services (OpenAI, Google Gemini, etc.)
* **Customer Support**: Create intelligent customer support bots
* **Lead Generation**: Build lead qualification and collection systems
* **Business Automation**: Appointment scheduling, order status inquiries
* **Custom Integrations**: API integrations, database queries, external services

= Quick Start =

1. **Install and activate** the plugin
2. **Import an n8n workflow template** (included with the plugin)
3. **Configure your webhook URL** in WordPress admin
4. **Test the connection** and start chatting!

= n8n Workflow Templates =

The plugin includes ready-to-use n8n workflow templates:
* `n8n-workflow-template.json` - Complete template with proper response formatting
* `n8n-simple-example.json` - Simple example that works immediately

= Response Format Support =

Your n8n workflow can respond in multiple formats:

**JSON Object (Recommended):**
```json
{
  "message": "Your response message here",
  "success": true,
  "timestamp": "2024-01-01 12:00:00"
}
```

**Simple JSON:**
```json
{
  "message": "Your response message here",
  "success": true
}
```

**Plain String:**
```
Your response message here
```

= Customization Options =

* **5 Color Themes**: Sky Blue, Black, Pinkish, Green, Purple
* **4 Positions**: Bottom-right, bottom-left, top-right, top-left
* **Custom Title**: Change the chatbot title
* **Authentication**: Optional token-based authentication
* **HTTP Methods**: Support for POST, GET, PUT, DELETE, PATCH

= Security Features =

* Input sanitization and validation
* CSRF protection
* Rate limiting support
* Secure webhook communication
* Optional authentication

= Debug Tools =

* Built-in connection testing
* Detailed error logging
* Response analysis
* Debug scripts for troubleshooting

For detailed setup instructions, see the [Setup Guide](https://wordpress.org/plugins/agent-47/) or check the plugin documentation.

== Installation ==

= Automatic Installation (Recommended) =

1. Go to **Plugins > Add New** in your WordPress admin
2. Search for "Agent-47"
3. Click **Install Now**
4. Click **Activate**

= Manual Installation =

1. Download the plugin ZIP file
2. Go to **Plugins > Add New > Upload Plugin**
3. Choose the downloaded ZIP file
4. Click **Install Now**
5. Click **Activate**

= After Installation =

1. Go to **Settings > Chatbot n8n**
2. Enter your n8n webhook URL
3. Test the connection
4. Customize the chatbot appearance

= n8n Setup =

1. Import one of the provided workflow templates into n8n
2. Configure your AI agent or processing logic
3. Activate the workflow
4. Copy the webhook URL to WordPress

== Frequently Asked Questions ==

= What is n8n? =

n8n is a powerful workflow automation tool that allows you to connect different services and create automated workflows. It's perfect for building intelligent chatbots.

= Do I need to know how to code? =

No! The plugin includes ready-to-use n8n workflow templates that you can import and customize without coding.

= Can I use this with any AI service? =

Yes! Since it integrates with n8n, you can connect to any AI service that n8n supports, including OpenAI, Google Gemini, Claude, and many others.

= Is this plugin secure? =

Yes, the plugin includes multiple security features including input sanitization, CSRF protection, and secure webhook communication.

= Can I customize the chatbot appearance? =

Yes! You can choose from 5 different themes, 4 different positions, and customize the chatbot title.

= What if my n8n workflow doesn't work? =

The plugin includes comprehensive debugging tools to help you troubleshoot any issues. Check the error logs and use the built-in test connection feature.

= Can I use multiple chatbots? =

Yes! You can create multiple chatbot instances by using different n8n workflows with different webhook paths.

= Is there a free version? =

Yes, this plugin is completely free and open source under the GPL license.

== Screenshots ==

1. [WordPress Chatbot Plugin](https://raw.githubusercontent.com/surajjadhao/agent-47/main/assets/Wordpress_Chatbot_Plugin.png) - Chatbot widget on a website
2. [Chatbot Plugin Setting Panel](https://raw.githubusercontent.com/surajjadhao/agent-47/main/assets/Chatbot_Plugin_Setting_Panel.jpeg) - WordPress admin settings page
3. [Chatbot Plugin Webhook Test](https://raw.githubusercontent.com/surajjadhao/agent-47/main/assets/Chatbot_Plugin_Webhook_Test.jpeg) - Webhook testing and debugging tools

== Changelog ==

= 1.3.1 =
* **Fixed: WordPress Plugin Store Compliance** - Resolved all critical errors and warnings for plugin store submission
* **Enhanced: Security** - Fixed output escaping issues in admin and monitoring pages
* **Improved: Database Operations** - Fixed %i placeholder compatibility for WordPress versions below 6.2
* **Cleaned: Production Code** - Removed all error_log() debug statements from production files
* **Fixed: Input Sanitization** - Properly sanitized and unslashed all user inputs including HTTP_USER_AGENT
* **Updated: Short Description** - Reduced readme.txt short description to comply with 150 character limit
* **Enhanced: Uninstall Process** - Improved database cleanup and table removal in uninstall routine

= 1.3.0 =
* **Removed: Conversations Feature** - Completely removed the conversations option from backend as it was not useful and did not display any results
* **Cleaned: Database Structure** - Removed conversations table and related database operations
* **Simplified: Admin Interface** - Removed conversations submenu and page from WordPress admin
* **Optimized: Monitoring Dashboard** - Removed conversations statistics from monitoring page
* **Streamlined: Core Functionality** - Removed conversation history functions from core and webhook classes
* **Enhanced: Code Cleanup** - Removed all conversations-related code and references throughout the plugin

= 1.2.2 =
* **Fixed: Frontend UI Issues** - Improved padding, mobile responsiveness, font weight, and contrast
* **Enhanced: Mobile Responsiveness** - Fixed chatbot overflow issues on mobile devices
* **Improved: Typography** - Increased font weight to 500 for better readability
* **Enhanced: Spacing** - Improved line height (1.5) and message padding for professional appearance
* **Fixed: Contrast Issues** - Better text contrast with darker colors (#2c3e50) for improved readability
* **Added: Extra Small Screen Support** - New breakpoint for 360px screens and below
* **Improved: Message Padding** - Professional padding (12px 16px) for all message bubbles
* **Enhanced: Input Field** - Better placeholder text contrast and improved styling

= 1.2.0 =
* **Major Feature: Concurrent User Support** - Now handles 100+ concurrent users with session management
* **New: Monitoring Dashboard** - Real-time system monitoring with performance metrics
* **Enhanced: Message Interaction** - Users can now copy text and click links in chatbot messages
* **Improved: Rate Limiting** - Per-session rate limiting (60 messages/minute) to prevent abuse
* **New: Session Management** - Automatic cleanup of expired sessions and conversation history
* **Enhanced: Database Structure** - Optimized database tables for high concurrency
* **New: System Health Monitoring** - Visual indicators for system load and performance
* **Improved: Error Handling** - Better error messages and graceful degradation under load
* **Enhanced: Security** - Additional security measures for high-traffic scenarios
* **New: Admin Interface** - Dedicated monitoring and conversations pages in admin panel
* **Improved: User Experience** - Right-click context menu for text selection and copying
* **Enhanced: Link Handling** - Better link detection and clickable URLs in messages
* **New: Performance Metrics** - Track peak concurrent users and system performance
* **Improved: Memory Management** - Efficient memory usage and automatic cleanup
* **Enhanced: Scalability** - Production-ready for high-traffic websites

= 1.1.0 =
* Fixed hover functionality interference with other page elements
* Improved CSS scoping to prevent conflicts with other plugins/themes
* Enhanced conditional loading of resources (only when chatbot is enabled)
* Fixed critical security issues (SQL injection, XSS prevention, input sanitization)
* Added proper nonce verification and CSRF protection
* Implemented WordPress caching for better performance
* Fixed timezone safety issues (gmdate instead of date)
* Reduced readme.txt tags to comply with WordPress.org guidelines
* Added comprehensive error handling and debugging improvements
* Enhanced plugin deactivation cleanup

= 1.0.0 =
* Initial release
* Basic webhook integration
* Customizable UI themes
* Debug and testing tools
* Comprehensive documentation
* n8n workflow templates
* Multiple response format support
* Security features
* Mobile responsive design

== Upgrade Notice ==

= 1.3.1 =
This micro update addresses WordPress plugin store compliance issues. All critical errors and warnings have been resolved, including output escaping, input sanitization, and database compatibility issues. The plugin is now fully compliant with WordPress.org submission requirements.

= 1.3.0 =
This update focuses on code cleanup and feature removal. The conversations feature has been completely removed from the backend as it was not functional and did not provide any value. This simplifies the plugin architecture and removes unnecessary database operations and admin interface elements.

= 1.2.2 =
This micro update focuses on frontend UI improvements and mobile responsiveness. The chatbot now has better typography, improved contrast, professional spacing, and enhanced mobile support. All visual issues have been resolved for a more polished user experience.

= 1.2.0 =
This major update introduces enterprise-level scalability features. The plugin now supports 100+ concurrent users with advanced session management, real-time monitoring dashboard, and enhanced user interaction capabilities. Perfect for high-traffic websites and production environments.

= 1.1.0 =
This update includes critical security fixes and performance improvements. The hover functionality issue has been resolved, and the plugin now properly scopes its CSS to prevent conflicts with other page elements. All critical security vulnerabilities have been addressed.

= 1.0.0 =
Initial release of Agent-47. This plugin provides a complete solution for integrating n8n workflows with WordPress chatbots. 