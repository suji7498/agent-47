<?php
/**
 * Uninstall Agent-47 Plugin
 * 
 * This file is executed when the plugin is uninstalled.
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete plugin options
delete_option('agent_47_settings');

// Drop custom tables using WordPress functions
global $wpdb;

// Use WordPress functions for table operations
$wpdb->query("DROP TABLE IF EXISTS " . $wpdb->prefix . 'agent_47_messages');
$wpdb->query("DROP TABLE IF EXISTS " . $wpdb->prefix . 'agent_47_sessions');
$wpdb->query("DROP TABLE IF EXISTS " . $wpdb->prefix . 'agent_47_rate_limits');

// Clear any cached data
wp_cache_flush(); 