<?php
/**
 * Uninstall Agent-47 Plugin
 * 
 * This file is executed when the plugin is uninstalled.
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete plugin options
delete_option('agent_47_settings');

// Drop custom tables
global $wpdb;

$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}chatbot_messages");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}chatbot_sessions");

// Clear any cached data
wp_cache_flush(); 