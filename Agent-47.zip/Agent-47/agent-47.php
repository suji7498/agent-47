<?php
/**
 * Plugin Name: Agent-47
 * Plugin URI: https://wordpress.org/plugins/agent-47/
 * Description: A flexible WordPress plugin that integrates with n8n workflows to create intelligent chatbots for your website. Features customizable UI, multiple themes, and seamless n8n integration.
 * Version: 1.3.1
 * Author: Suraj Jadhao
 * Author URI: https://www.linkedin.com/in/suraj-jd/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: agent-47
 * Domain Path: /languages
 * Requires at least: 5.8
 * Tested up to: 6.8
 * Requires PHP: 7.4
 * 
 * @package Agent_47
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Plugin version
define('AGENT_47_VERSION', '1.3.1');

// Plugin path
define('AGENT_47_PATH', plugin_dir_path(__FILE__));

// Plugin URL
define('AGENT_47_URL', plugin_dir_url(__FILE__));

/**
 * Main plugin class
 */
class Agent_47 {
    
    /**
     * Plugin instance
     * @var Agent_47
     */
    private static $instance = null;
    
    /**
     * Get plugin instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init();
    }
    
    /**
     * Initialize plugin
     */
    private function init() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('admin_head', array($this, 'add_plugin_icon'));
        
        // Load classes
        $this->load_dependencies();
        
        // Initialize components
        if (is_admin()) {
            new Agent_47_Admin();
        }
        
        // Only initialize public components if chatbot is enabled
        $settings = get_option('agent_47_settings', array());
        if (isset($settings['chatbot_enabled']) && $settings['chatbot_enabled']) {
            new Agent_47_Public();
        }
        
        new Agent_47_API();
        
        // Add HTTP filters for better localhost handling
        add_filter('http_request_args', array($this, 'modify_http_request_args'), 10, 2);
        
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Load plugin dependencies
     */
    private function load_dependencies() {
        require_once AGENT_47_PATH . 'includes/class-chatbot-core.php';
        require_once AGENT_47_PATH . 'includes/class-chatbot-api.php';
        require_once AGENT_47_PATH . 'includes/class-chatbot-webhook.php';
        require_once AGENT_47_PATH . 'includes/class-chatbot-database.php';
        require_once AGENT_47_PATH . 'includes/class-chatbot-security.php';
        
        if (is_admin()) {
            require_once AGENT_47_PATH . 'admin/class-chatbot-admin.php';
        }
        
        require_once AGENT_47_PATH . 'public/class-chatbot-public.php';
    }
    

    
    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_frontend_scripts() {
        // Only load scripts and styles if chatbot is enabled
        $settings = get_option('agent_47_settings', array());
        if (!isset($settings['chatbot_enabled']) || !$settings['chatbot_enabled']) {
            return;
        }
        
        wp_enqueue_script(
            'agent-47-frontend',
            AGENT_47_URL . 'public/js/chatbot-frontend.js',
            array('jquery'),
            AGENT_47_VERSION,
            true
        );
        
        wp_enqueue_script(
            'agent-47-ajax',
            AGENT_47_URL . 'public/js/chatbot-ajax.js',
            array('jquery'),
            AGENT_47_VERSION . '.' . get_option('agent_47_assets_version', time()),
            true
        );
        
        wp_enqueue_style(
            'agent-47-style',
            AGENT_47_URL . 'public/css/chatbot-style.css',
            array(),
            AGENT_47_VERSION . '.' . get_option('agent_47_assets_version', time())
        );
        
        // Localize script for AJAX
        wp_localize_script('agent-47-ajax', 'chatbot_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('chatbot_nonce'),
            'rest_url' => rest_url('agent-47/v1/'),
            'rest_nonce' => wp_create_nonce('wp_rest')
        ));
    }
    
    /**
     * Add plugin icon to admin
     */
    public function add_plugin_icon() {
        ?>
        <style>
        .plugin-icon.agent-47 {
            background-image: url('<?php echo esc_url(AGENT_47_URL . 'assets/Agent-47_Logo.png'); ?>') !important;
            background-size: contain !important;
            background-repeat: no-repeat !important;
            background-position: center !important;
        }
        </style>
        <?php
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        // Load on all Agent-47 admin pages
        if (strpos($hook, 'agent-47') === false) {
            return;
        }
        
        wp_enqueue_script(
            'agent-47-admin',
            AGENT_47_URL . 'admin/js/admin-script.js',
            array('jquery'),
            AGENT_47_VERSION,
            true
        );
        
        wp_enqueue_style(
            'agent-47-admin-style',
            AGENT_47_URL . 'admin/css/admin-style.css',
            array(),
            AGENT_47_VERSION
        );
        
        // Localize admin script for AJAX
        wp_localize_script('agent-47-admin', 'chatbot_admin_nonce', wp_create_nonce('chatbot_admin_nonce'));
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create database tables
        $database = new Agent_47_Database();
        $database->create_tables();
        
        // Set default options
        add_option('agent_47_settings', array(
            'n8n_webhook_url' => '',
            'webhook_http_method' => 'POST',
            'chatbot_title' => __('Chat Assistant', 'agent-47'),
            'chatbot_enabled' => true,
            'chat_position' => 'bottom-right'
        ));
        
        // Flush rewrite rules for REST API
        flush_rewrite_rules();
        
        // Clear all caches
        wp_cache_flush();
        
        // Clear any object cache
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
        
        // Clear any transients
        delete_transient('agent_47_cache');
        
        // Force refresh of assets
        update_option('agent_47_assets_version', time());
        
        // Force refresh assets version immediately
        update_option('agent_47_assets_version', time());
    }
    
    /**
     * Force refresh assets version (for cache busting)
     */
    public function force_refresh_assets() {
        update_option('agent_47_assets_version', time());
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up temporary data if needed
        flush_rewrite_rules();
        
        // Clear any cached data
        wp_cache_flush();
        
        // Remove any scheduled events
        wp_clear_scheduled_hook('agent_47_cleanup');
    }
    
    /**
     * Modify HTTP request args for better localhost handling
     */
    public function modify_http_request_args($args, $url) {
        // If the URL contains localhost, add some modifications for better compatibility
        if (strpos($url, 'localhost') !== false || strpos($url, '127.0.0.1') !== false) {
            $args['sslverify'] = false;
            $args['timeout'] = 30;
            $args['httpversion'] = '1.1';
        }
        return $args;
    }
}

// Initialize the plugin
Agent_47::get_instance(); 