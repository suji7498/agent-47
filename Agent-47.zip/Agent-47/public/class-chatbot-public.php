<?php
/**
 * Frontend chatbot display
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Chatbot_N8N_Public {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('wp_footer', array($this, 'display_chatbot'));
        add_action('wp_ajax_chatbot_send_message', array($this, 'ajax_send_message'));
        add_action('wp_ajax_nopriv_chatbot_send_message', array($this, 'ajax_send_message'));
    }
    
    /**
     * Display chatbot widget
     */
    public function display_chatbot() {
        $settings = get_option('wp_chatbot_n8n_settings', array());
        
        // Check if chatbot is enabled
        if (!isset($settings['chatbot_enabled']) || !$settings['chatbot_enabled']) {
            return;
        }
        
        $title = $settings['chatbot_title'] ?? __('Chat Assistant', 'wp-chatbot-n8n');
        $position = $settings['chat_position'] ?? 'bottom-right';
        $theme = $settings['chatbot_theme'] ?? 'skyblue';
        
        ?>
        <div id="wp-chatbot-widget" class="chatbot-widget chatbot-position-<?php echo esc_attr($position); ?> theme-<?php echo esc_attr($theme); ?>">
            <div class="chatbot-toggle" id="chatbot-toggle">
                <span class="chatbot-icon">💬</span>
            </div>
            <div class="chatbot-container" id="chatbot-container" style="display: none;">
                <div class="chatbot-header">
                    <h4><?php echo esc_html($title); ?></h4>
                    <button class="chatbot-close" id="chatbot-close">&times;</button>
                </div>
                <div class="chatbot-messages" id="chatbot-messages">
                    <div class="message bot-message">
                        <div class="message-content">
                            <?php _e('Hello! How can I help you today?', 'wp-chatbot-n8n'); ?>
                        </div>
                    </div>
                </div>
                <div class="chatbot-input-container">
                    <input type="text" id="chatbot-input" placeholder="<?php esc_attr_e('Type your message...', 'wp-chatbot-n8n'); ?>" maxlength="1000">
                    <button id="chatbot-send"><?php _e('Send', 'wp-chatbot-n8n'); ?></button>
                </div>
                <div class="chatbot-loading" id="chatbot-loading" style="display: none;">
                    <div class="loading-dots">
                        <span></span><span></span><span></span>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * AJAX handler for sending messages
     */
    public function ajax_send_message() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'chatbot_nonce')) {
            wp_send_json_error(__('Security check failed', 'wp-chatbot-n8n'));
        }
        
        // Get message
        $message = sanitize_textarea_field($_POST['message'] ?? '');
        $session_id = sanitize_text_field($_POST['session_id'] ?? '');
        
        if (empty($message)) {
            wp_send_json_error(__('Empty message', 'wp-chatbot-n8n'));
        }
        
        // Check rate limiting
        $user_ip = $this->get_client_ip();
        if (!WP_Chatbot_N8N_Security::check_rate_limit($user_ip)) {
            wp_send_json_error(__('Too many requests. Please wait a moment.', 'wp-chatbot-n8n'));
        }
        
        // Process message
        $response = WP_Chatbot_N8N_Core::process_message($message, $session_id);
        
        if ($response['success']) {
            wp_send_json_success(array(
                'message' => $response['message'],
                'session_id' => $response['session_id']
            ));
        } else {
            wp_send_json_error($response['message']);
        }
    }
    
    /**
     * Get client IP address
     */
    private function get_client_ip() {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '';
    }
} 