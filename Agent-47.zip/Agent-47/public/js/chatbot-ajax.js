/**
 * Agent-47 Chatbot AJAX Handler
 * Handles AJAX communication for the chatbot
 */

(function($) {
    'use strict';

    // Global variables
    let sessionId = null;
    let isProcessing = false;

    /**
     * Initialize AJAX functionality
     */
    function init() {
        // Generate session ID if not exists
        if (!sessionId) {
            sessionId = 'chat_' + Math.random().toString(36).substr(2, 9);
        }

        // Bind events
        bindEvents();
    }

    /**
     * Bind event handlers
     */
    function bindEvents() {
        // Send button click
        $(document).on('click', '#chatbot-send', sendMessage);
        
        // Enter key press
        $(document).on('keypress', '#chatbot-input', function(e) {
            if (e.which === 13 && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
    }

    /**
     * Send message via AJAX
     */
    function sendMessage() {
        const input = $('#chatbot-input');
        const message = input.val().trim();
        
        if (!message || isProcessing) {
            return;
        }

        // Prevent multiple requests
        isProcessing = true;
        
        // Clear input
        input.val('');
        
        // Add user message to chat
        addMessage(message, 'user');
        
        // Show loading indicator
        showLoading(true);
        
        // Prepare data
        const data = {
            action: 'chatbot_send_message',
            message: message,
            session_id: sessionId,
            nonce: chatbot_ajax.nonce
        };

        // Send AJAX request
        $.ajax({
            url: chatbot_ajax.ajax_url,
            type: 'POST',
            data: data,
            dataType: 'json',
            timeout: 30000,
            success: function(response) {
                if (response.success) {
                    // Add bot response to chat
                    addMessage(response.data.message, 'bot');
                    
                    // Update session ID if provided
                    if (response.data.session_id) {
                        sessionId = response.data.session_id;
                    }
                } else {
                    // Show error message
                    addMessage('Sorry, I encountered an error. Please try again.', 'bot error');
                }
            },
            error: function(xhr, status, error) {
                console.error('Chatbot AJAX error:', error);
                addMessage('Sorry, I\'m having trouble connecting. Please try again.', 'bot error');
            },
            complete: function() {
                // Hide loading indicator
                showLoading(false);
                
                // Reset processing flag
                isProcessing = false;
                
                // Scroll to bottom
                scrollToBottom();
            }
        });
    }

    /**
     * Add message to chat
     */
    function addMessage(message, sender) {
        const messagesContainer = $('#chatbot-messages');
        const messageClass = sender === 'user' ? 'user-message' : 'bot-message';
        const errorClass = sender.includes('error') ? ' error' : '';
        
        const messageHtml = `
            <div class="message ${messageClass}${errorClass}">
                <div class="message-content">
                    ${escapeHtml(message)}
                </div>
            </div>
        `;
        
        messagesContainer.append(messageHtml);
    }

    /**
     * Show/hide loading indicator
     */
    function showLoading(show) {
        const loading = $('#chatbot-loading');
        if (show) {
            loading.show();
        } else {
            loading.hide();
        }
    }

    /**
     * Scroll chat to bottom
     */
    function scrollToBottom() {
        const messagesContainer = $('#chatbot-messages');
        messagesContainer.scrollTop(messagesContainer[0].scrollHeight);
    }

    /**
     * Escape HTML to prevent XSS
     */
    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }

    /**
     * Get chat history via REST API
     */
    function getChatHistory(sessionId, limit = 50) {
        return $.ajax({
            url: chatbot_ajax.rest_url + 'history/' + sessionId,
            type: 'GET',
            data: { limit: limit },
            headers: {
                'X-WP-Nonce': chatbot_ajax.rest_nonce
            },
            dataType: 'json'
        });
    }

    /**
     * Send message via REST API
     */
    function sendMessageRest(message, sessionId) {
        return $.ajax({
            url: chatbot_ajax.rest_url + 'message',
            type: 'POST',
            data: JSON.stringify({
                message: message,
                session_id: sessionId
            }),
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': chatbot_ajax.rest_nonce
            },
            dataType: 'json'
        });
    }

    // Initialize when document is ready
    $(document).ready(function() {
        init();
    });

    // Expose functions globally for debugging
    window.Agent47Ajax = {
        sendMessage: sendMessage,
        getChatHistory: getChatHistory,
        sendMessageRest: sendMessageRest,
        addMessage: addMessage
    };

})(jQuery); 