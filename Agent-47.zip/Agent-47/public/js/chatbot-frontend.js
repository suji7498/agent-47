/**
 * Frontend chatbot interface
 */

(function($) {
    'use strict';
    
    class ChatbotInterface {
        
        constructor() {
            this.sessionId = null;
            this.isOpen = false;
            this.notificationShown = false;
            this.notificationTimer = null;
            this.init();
        }
        
        init() {
            this.bindEvents();
            this.generateSessionId();
            this.startNotificationTimer();
        }
        
        bindEvents() {
            const self = this;
            
            // Toggle chat widget
            $(document).on('click', '#chatbot-toggle', function() {
                self.toggleChat();
                self.hideNotification();
            });
            
            // Close chat widget
            $(document).on('click', '#chatbot-close', function() {
                self.closeChat();
            });
            
            // Send message on button click
            $(document).on('click', '#chatbot-send', function() {
                self.sendMessage();
                self.hideNotification();
            });
            
            // Send message on Enter key
            $(document).on('keypress', '#chatbot-input', function(e) {
                if (e.which === 13 && !e.shiftKey) {
                    e.preventDefault();
                    self.sendMessage();
                    self.hideNotification();
                }
            });
            
            // Hide notification when user interacts with chat
            $(document).on('click', '#chatbot-container', function() {
                self.hideNotification();
            });
            

            
            // Handle link clicks with visual feedback
            $(document).on('click', '#wp-chatbot-widget .chatbot-link', function(e) {
                const link = $(this);
                link.addClass('link-clicked');
                setTimeout(() => {
                    link.removeClass('link-clicked');
                }, 200);
            });
            

        }
        
        toggleChat() {
            if (this.isOpen) {
                this.closeChat();
            } else {
                this.openChat();
            }
        }
        
        openChat() {
            $('#chatbot-container').slideDown(300);
            $('#chatbot-toggle').addClass('active');
            $('#chatbot-input').focus();
            this.isOpen = true;
        }
        
        closeChat() {
            $('#chatbot-container').slideUp(300);
            $('#chatbot-toggle').removeClass('active');
            this.isOpen = false;
        }
        
        sendMessage() {
            const message = $('#chatbot-input').val().trim();
            
            if (!message) {
                return;
            }
            
            // Add user message to chat
            this.addMessage(message, 'user');
            
            // Clear input
            $('#chatbot-input').val('');
            
            // Show loading
            this.showLoading();
            
            // Send to backend
            this.sendToBackend(message);
        }
        
        addMessage(message, sender) {
            let processedMessage = message;
            
            // Make links clickable for bot messages
            if (sender === 'bot') {
                // Check if message already contains HTML (like from n8n)
                if (message.includes('<a href=') || message.includes('target="_blank"')) {
                    // Message already has HTML, just clean it up
                    processedMessage = this.cleanHtmlMessage(message);
                } else {
                    // Process plain text and make links clickable
                    processedMessage = this.makeLinksClickable(message);
                }
            } else {
                processedMessage = this.escapeHtml(message);
            }
            
            const messageHtml = `
                <div class="message ${sender}-message">
                    <div class="message-content">
                        ${processedMessage}
                    </div>
                    <div class="message-time">
                        ${new Date().toLocaleTimeString()}
                    </div>
                </div>
            `;
            
            $('#chatbot-messages').append(messageHtml);
            this.scrollToBottom();
        }
        
        sendToBackend(message) {
            const self = this;
            
            $.ajax({
                url: chatbot_ajax.ajax_url,
                method: 'POST',
                data: {
                    action: 'chatbot_send_message',
                    message: message,
                    session_id: this.sessionId,
                    nonce: chatbot_ajax.nonce
                },
                success: function(response) {
                    self.hideLoading();
                    
                    if (response.success && response.data.message) {
                        self.addMessage(response.data.message, 'bot');
                        self.sessionId = response.data.session_id;
                    } else {
                        self.addMessage('Sorry, I encountered an error. Please try again.', 'bot');
                    }
                },
                error: function(xhr, status, error) {
                    self.hideLoading();
                    console.error('Chatbot error:', error);
                    self.addMessage('Sorry, I\'m having trouble connecting. Please try again later.', 'bot');
                }
            });
        }
        
        showLoading() {
            $('#chatbot-loading').show();
            this.scrollToBottom();
        }
        
        hideLoading() {
            $('#chatbot-loading').hide();
        }
        
        scrollToBottom() {
            const messagesContainer = $('#chatbot-messages');
            messagesContainer.scrollTop(messagesContainer[0].scrollHeight);
        }
        
        generateSessionId() {
            this.sessionId = 'chat_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        }
        
        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        cleanHtmlMessage(text) {
            // If the message contains broken HTML (like escaped HTML), fix it
            if (text.includes('&lt;a href=') || text.includes('&gt;') || text.includes('&lt;/a&gt;')) {
                // Decode HTML entities
                const div = document.createElement('div');
                div.innerHTML = text;
                text = div.textContent;
                
                // Now process it as regular text to make links clickable
                return this.makeLinksClickable(text);
            }
            
            // If it contains raw HTML attributes or broken HTML, clean them completely
            if (text.includes('target="_blank"') || text.includes('rel=') || text.includes('class=') || text.includes('title=')) {
                // Extract URLs and text from broken HTML
                const urlMatch = text.match(/href="([^"]*)"/);
                const textMatch = text.match(/>([^<]*)</);
                
                if (urlMatch && textMatch) {
                    const url = urlMatch[1];
                    const linkText = textMatch[1];
                    return this.makeLinksClickable(`${linkText} (${url})`);
                } else {
                    // If we can't extract properly, just return the text content
                    const div = document.createElement('div');
                    div.innerHTML = text;
                    return this.makeLinksClickable(div.textContent || div.innerText || text);
                }
            }
            
            // If it's proper HTML, just return it
            return text;
        }
        
        makeLinksClickable(text) {
            // First, handle BB code format [text](url)
            const bbCodeRegex = /\[([^\]]+)\]\(([^)]+)\)/g;
            text = text.replace(bbCodeRegex, function(match, linkText, url) {
                // Ensure URL has protocol
                let fullUrl = url;
                if (url.toLowerCase().startsWith('www.')) {
                    fullUrl = 'https://' + url;
                }
                
                // Clean up URL (remove trailing punctuation)
                fullUrl = fullUrl.replace(/[.,;!?]+$/, '');
                
                // Escape HTML for the URL
                const escapedUrl = fullUrl.replace(/&/g, '&amp;')
                                        .replace(/</g, '&lt;')
                                        .replace(/>/g, '&gt;')
                                        .replace(/"/g, '&quot;')
                                        .replace(/'/g, '&#039;');
                
                // Escape HTML for display text
                const escapedText = linkText.replace(/&/g, '&amp;')
                                          .replace(/</g, '&lt;')
                                          .replace(/>/g, '&gt;')
                                          .replace(/"/g, '&quot;')
                                          .replace(/'/g, '&#039;');
                
                return `<a href="${escapedUrl}" target="_blank" rel="noopener noreferrer" class="chatbot-link" title="Click to open link">${escapedText}</a>`;
            });
            
            // Then handle plain URLs
            const urlRegex = /(https?:\/\/[^\s<>"']+|www\.[^\s<>"']+)/gi;
            
            return text.replace(urlRegex, function(url) {
                // Ensure URL has protocol
                let fullUrl = url;
                if (url.toLowerCase().startsWith('www.')) {
                    fullUrl = 'https://' + url;
                }
                
                // Clean up URL (remove trailing punctuation)
                fullUrl = fullUrl.replace(/[.,;!?]+$/, '');
                
                // Escape HTML for the URL
                const escapedUrl = fullUrl.replace(/&/g, '&amp;')
                                        .replace(/</g, '&lt;')
                                        .replace(/>/g, '&gt;')
                                        .replace(/"/g, '&quot;')
                                        .replace(/'/g, '&#039;');
                
                // Escape HTML for display text
                const displayText = url.replace(/&/g, '&amp;')
                                     .replace(/</g, '&lt;')
                                     .replace(/>/g, '&gt;')
                                     .replace(/"/g, '&quot;')
                                     .replace(/'/g, '&#039;');
                
                return `<a href="${escapedUrl}" target="_blank" rel="noopener noreferrer" class="chatbot-link" title="Click to open link">${displayText}</a>`;
            });
        }
        
        startNotificationTimer() {
            const self = this;
            this.notificationTimer = setTimeout(function() {
                self.showNotification();
            }, 10000); // 10 seconds
        }
        
        showNotification() {
            if (this.notificationShown || this.isOpen) {
                return;
            }
            
            this.notificationShown = true;
            
            // Create notification element
            const notification = $(`
                <div id="chatbot-notification" class="chatbot-notification">
                    <div class="notification-content">
                        <span class="notification-text">Need Help?</span>
                        <button class="notification-close">&times;</button>
                    </div>
                </div>
            `);
            
            // Add to page
            $('#wp-chatbot-widget').append(notification);
            
            // Show notification with animation
            notification.fadeIn(300);
            
            // Play beep sound
            this.playBeepSound();
            
            // Auto-hide after 5 seconds
            setTimeout(() => {
                this.hideNotification();
            }, 5000);
            
            // Close button event
            notification.find('.notification-close').on('click', () => {
                this.hideNotification();
            });
        }
        
        hideNotification() {
            if (this.notificationTimer) {
                clearTimeout(this.notificationTimer);
                this.notificationTimer = null;
            }
            
            $('#chatbot-notification').fadeOut(300, function() {
                $(this).remove();
            });
            
            this.notificationShown = false;
        }
        
        playBeepSound() {
            try {
                // Create audio context for beep sound
                const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                const oscillator = audioContext.createOscillator();
                const gainNode = audioContext.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(audioContext.destination);
                
                oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
                oscillator.type = 'sine';
                
                gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
                
                oscillator.start(audioContext.currentTime);
                oscillator.stop(audioContext.currentTime + 0.3);
            } catch (error) {
                console.log('Could not play beep sound:', error);
            }
        }
        

        

    }
    
    // Initialize chatbot when document is ready
    $(document).ready(function() {
        new ChatbotInterface();
    });
    
})(jQuery); 