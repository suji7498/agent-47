/**
 * Frontend chatbot interface
 */

(function($) {
    'use strict';
    
    class ChatbotInterface {
        
        constructor() {
            this.sessionId = null;
            this.isOpen = false;
            this.notificationShown = false;
            this.notificationTimer = null;
            this.init();
        }
        
        init() {
            this.bindEvents();
            this.generateSessionId();
            this.startNotificationTimer();
        }
        
        bindEvents() {
            const self = this;
            
            // Toggle chat widget
            $(document).on('click', '#chatbot-toggle', function() {
                self.toggleChat();
                self.hideNotification();
            });
            
            // Close chat widget
            $(document).on('click', '#chatbot-close', function() {
                self.closeChat();
            });
            
            // Send message on button click
            $(document).on('click', '#chatbot-send', function() {
                self.sendMessage();
                self.hideNotification();
            });
            
            // Send message on Enter key
            $(document).on('keypress', '#chatbot-input', function(e) {
                if (e.which === 13 && !e.shiftKey) {
                    e.preventDefault();
                    self.sendMessage();
                    self.hideNotification();
                }
            });
            
            // Hide notification when user interacts with chat
            $(document).on('click', '#chatbot-container', function() {
                self.hideNotification();
            });
        }
        
        toggleChat() {
            if (this.isOpen) {
                this.closeChat();
            } else {
                this.openChat();
            }
        }
        
        openChat() {
            $('#chatbot-container').slideDown(300);
            $('#chatbot-toggle').addClass('active');
            $('#chatbot-input').focus();
            this.isOpen = true;
        }
        
        closeChat() {
            $('#chatbot-container').slideUp(300);
            $('#chatbot-toggle').removeClass('active');
            this.isOpen = false;
        }
        
        sendMessage() {
            const message = $('#chatbot-input').val().trim();
            
            if (!message) {
                return;
            }
            
            // Add user message to chat
            this.addMessage(message, 'user');
            
            // Clear input
            $('#chatbot-input').val('');
            
            // Show loading
            this.showLoading();
            
            // Send to backend
            this.sendToBackend(message);
        }
        
        addMessage(message, sender) {
            const messageHtml = `
                <div class="message ${sender}-message">
                    <div class="message-content">
                        ${this.escapeHtml(message)}
                    </div>
                    <div class="message-time">
                        ${new Date().toLocaleTimeString()}
                    </div>
                </div>
            `;
            
            $('#chatbot-messages').append(messageHtml);
            this.scrollToBottom();
        }
        
        sendToBackend(message) {
            const self = this;
            
            $.ajax({
                url: chatbot_ajax.ajax_url,
                method: 'POST',
                data: {
                    action: 'chatbot_send_message',
                    message: message,
                    session_id: this.sessionId,
                    nonce: chatbot_ajax.nonce
                },
                success: function(response) {
                    self.hideLoading();
                    
                    if (response.success && response.data.message) {
                        self.addMessage(response.data.message, 'bot');
                        self.sessionId = response.data.session_id;
                    } else {
                        self.addMessage('Sorry, I encountered an error. Please try again.', 'bot');
                    }
                },
                error: function(xhr, status, error) {
                    self.hideLoading();
                    console.error('Chatbot error:', error);
                    self.addMessage('Sorry, I\'m having trouble connecting. Please try again later.', 'bot');
                }
            });
        }
        
        showLoading() {
            $('#chatbot-loading').show();
            this.scrollToBottom();
        }
        
        hideLoading() {
            $('#chatbot-loading').hide();
        }
        
        scrollToBottom() {
            const messagesContainer = $('#chatbot-messages');
            messagesContainer.scrollTop(messagesContainer[0].scrollHeight);
        }
        
        generateSessionId() {
            this.sessionId = 'chat_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        }
        
        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        startNotificationTimer() {
            const self = this;
            this.notificationTimer = setTimeout(function() {
                self.showNotification();
            }, 10000); // 10 seconds
        }
        
        showNotification() {
            if (this.notificationShown || this.isOpen) {
                return;
            }
            
            this.notificationShown = true;
            
            // Create notification element
            const notification = $(`
                <div id="chatbot-notification" class="chatbot-notification">
                    <div class="notification-content">
                        <span class="notification-text">Need Help?</span>
                        <button class="notification-close">&times;</button>
                    </div>
                </div>
            `);
            
            // Add to page
            $('#wp-chatbot-widget').append(notification);
            
            // Show notification with animation
            notification.fadeIn(300);
            
            // Play beep sound
            this.playBeepSound();
            
            // Auto-hide after 5 seconds
            setTimeout(() => {
                this.hideNotification();
            }, 5000);
            
            // Close button event
            notification.find('.notification-close').on('click', () => {
                this.hideNotification();
            });
        }
        
        hideNotification() {
            if (this.notificationTimer) {
                clearTimeout(this.notificationTimer);
                this.notificationTimer = null;
            }
            
            $('#chatbot-notification').fadeOut(300, function() {
                $(this).remove();
            });
            
            this.notificationShown = false;
        }
        
        playBeepSound() {
            try {
                // Create audio context for beep sound
                const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                const oscillator = audioContext.createOscillator();
                const gainNode = audioContext.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(audioContext.destination);
                
                oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
                oscillator.type = 'sine';
                
                gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
                
                oscillator.start(audioContext.currentTime);
                oscillator.stop(audioContext.currentTime + 0.3);
            } catch (error) {
                console.log('Could not play beep sound:', error);
            }
        }
    }
    
    // Initialize chatbot when document is ready
    $(document).ready(function() {
        new ChatbotInterface();
    });
    
})(jQuery); 