<?php
// Force refresh assets version
update_option('agent_47_assets_version', time());
echo esc_html("Cache refreshed! New timestamp: " . get_option('agent_47_assets_version'));
?> 